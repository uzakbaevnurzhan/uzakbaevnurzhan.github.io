OraculAi - AndroidIDE-ready project (max features)
==================================================

Описание:
- Пакет: com.oracul.ai
- Имя: OraculAI
- WebView открывает https://oracul-ai.lovable.app/
- Полный набор runtime permissions (camera, mic, location, storage)
- Pull-to-refresh, download support, share, back/forward/home buttons
- FLAG_SECURE (no screenshots), network_security_config (pinning placeholder)
- ProGuard enabled for release builds (minify)
- Gradle wrapper set to 6.1.1 and AGP 4.1.3 for AndroidIDE compatibility

Сборка в AndroidIDE:
1. Распакуй этот архив.
2. Открой папку в AndroidIDE (или Android Studio).
3. Если AndroidIDE запрашивает импорт Gradle, выбери "Use local gradle wrapper".
4. Build -> Assemble Debug или Build APK.
5. APK будет в app/build/outputs/apk/debug/app-debug.apk

ЗАМЕНЫ/ВАЖНО:
- network_security_config.xml: замените значение PIN на SHA-256 сертификата вашего сервера.
- При необходимости замени иконки mipmap-*/ic_launcher.png на свои.
- Для выпуска подпишите релизный APK через signingConfig в app/build.gradle.
