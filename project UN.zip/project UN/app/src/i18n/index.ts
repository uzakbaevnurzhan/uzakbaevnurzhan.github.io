// Simple i18n implementation

export const languages = [
  { code: 'ru', name: 'Русский', nativeName: 'Русский', flag: '🇷🇺' },
  { code: 'en', name: 'English', nativeName: 'English', flag: '🇬🇧' },
  { code: 'kk', name: 'Қазақша', nativeName: 'Қазақша', flag: '🇰🇿' },
  { code: 'de', name: 'Deutsch', nativeName: 'Deutsch', flag: '🇩🇪' },
  { code: 'fr', name: 'Français', nativeName: 'Français', flag: '🇫🇷' },
  { code: 'es', name: 'Español', nativeName: 'Español', flag: '🇪🇸' },
  { code: 'zh', name: '中文', nativeName: '中文', flag: '🇨🇳' },
  { code: 'ja', name: '日本語', nativeName: '日本語', flag: '🇯🇵' }
];

const translations: Record<string, Record<string, string>> = {
  ru: {
    // Navigation
    'nav.home': 'Главная',
    'nav.profile': 'Профиль',
    'nav.settings': 'Настройки',
    'nav.login': 'Вход',
    'nav.register': 'Регистрация',
    'nav.logout': 'Выход',
    'nav.back': 'Назад',
    'nav.close': 'Закрыть',

    // Home
    'home.title': 'Офлайн Веб-Приложение',
    'home.welcome': 'Добро пожаловать!',
    'home.description': 'Это веб-приложение работает офлайн и имеет систему автоматических обновлений.',
    'home.offline_ready': 'Приложение готово к работе офлайн',
    'home.update_available': 'Доступно обновление',
    'home.cached_content': 'Кэшированный контент',
    'home.pages': 'страниц',
    'home.assets': 'ресурсов',

    // Profile
    'profile.title': 'Личный профиль',
    'profile.info': 'Информация о пользователе',
    'profile.username': 'Имя пользователя',
    'profile.email': 'Email',
    'profile.created': 'Дата регистрации',
    'profile.lastLogin': 'Последний вход',
    'profile.edit': 'Редактировать профиль',
    'profile.changePassword': 'Сменить пароль',
    'profile.save': 'Сохранить',
    'profile.cancel': 'Отмена',

    // Settings
    'settings.title': 'Настройки',
    'settings.appearance': 'Внешний вид',
    'settings.theme': 'Тема',
    'settings.theme.dark': 'Тёмная',
    'settings.theme.light': 'Светлая',
    'settings.theme.auto': 'Авто',
    'settings.language': 'Язык',
    'settings.fontSize': 'Размер текста',
    'settings.fontSize.small': 'Маленький',
    'settings.fontSize.medium': 'Средний',
    'settings.fontSize.large': 'Большой',

    'settings.notifications': 'Уведомления',
    'settings.notifications.enable': 'Включить уведомления',
    'settings.notifications.description': 'Получать уведомления о новых версиях',

    'settings.updates': 'Обновления',
    'settings.autoUpdate': 'Автоматическая проверка обновлений',
    'settings.updateInterval': 'Интервал проверки',
    'settings.checkUpdate': 'Проверить обновление',
    'settings.checking': 'Проверка...',
    'settings.updateHistory': 'История обновлений',

    'settings.network': 'Сеть',
    'settings.dataSaver': 'Режим экономии трафика',
    'settings.dataSaver.description': 'Уменьшает использование данных',
    'settings.offlineMode': 'Офлайн-режим',
    'settings.offlineMode.description': 'Работать только с кэшированным контентом',
    'settings.cache': 'Кэш',
    'settings.cache.clear': 'Очистить кэш',
    'settings.cache.size': 'Размер кэша',

    'settings.security': 'Безопасность',
    'settings.security.encryption': 'Шифрование данных',
    'settings.security.encrypted': 'Данные зашифрованы',

    'settings.reset': 'Сбросить настройки',
    'settings.about': 'О приложении',
    'settings.version': 'Версия',

    // Update
    'update.title': 'Обновление',
    'update.checking': 'Проверка обновлений...',
    'update.noUpdates': 'Нет обновлений',
    'update.noUpdates.message': 'У вас установлена последняя версия.',
    'update.available': 'Доступно обновление',
    'update.version': 'Версия',
    'update.size': 'Размер',
    'update.releaseDate': 'Дата выпуска',
    'update.changelog': 'Что нового',
    'update.start': 'Начать обновление',
    'update.downloading': 'Загрузка...',
    'update.installing': 'Установка...',
    'update.completed': 'Загрузка завершена',
    'update.completed.message': 'Приложение будет перезапущено.',
    'update.restart': 'Перезапустить',
    'update.error': 'Ошибка обновления',
    'update.retry': 'Повторить',

    // History
    'history.title': 'История обновлений',
    'history.empty': 'История пуста',
    'history.version': 'Версия',
    'history.date': 'Дата',
    'history.size': 'Размер',
    'history.status': 'Статус',
    'history.status.success': 'Успешно',
    'history.status.failed': 'Ошибка',

    // Auth
    'auth.login.title': 'Вход в аккаунт',
    'auth.login.username': 'Имя пользователя',
    'auth.login.password': 'Пароль',
    'auth.login.submit': 'Войти',
    'auth.login.forgot': 'Забыли пароль?',
    'auth.login.noAccount': 'Нет аккаунта?',
    'auth.login.register': 'Зарегистрироваться',

    'auth.register.title': 'Регистрация',
    'auth.register.username': 'Имя пользователя',
    'auth.register.email': 'Email',
    'auth.register.password': 'Пароль',
    'auth.register.confirmPassword': 'Подтвердите пароль',
    'auth.register.submit': 'Зарегистрироваться',
    'auth.register.hasAccount': 'Уже есть аккаунт?',
    'auth.register.login': 'Войти',

    'auth.error.invalidCredentials': 'Неверное имя пользователя или пароль',
    'auth.error.userExists': 'Пользователь уже существует',
    'auth.error.passwordMismatch': 'Пароли не совпадают',
    'auth.error.required': 'Обязательное поле',

    // Network
    'network.offline': 'Нет интернета',
    'network.offline.message': 'Проверьте подключение к интернету',
    'network.online': 'Подключено',

    // Common
    'common.loading': 'Загрузка...',
    'common.save': 'Сохранить',
    'common.cancel': 'Отмена',
    'common.delete': 'Удалить',
    'common.edit': 'Редактировать',
    'common.close': 'Закрыть',
    'common.confirm': 'Подтвердить',
    'common.yes': 'Да',
    'common.no': 'Нет',
    'common.success': 'Успешно',
    'common.error': 'Ошибка',
    'common.warning': 'Предупреждение',
    'common.info': 'Информация'
  },

  en: {
    // Navigation
    'nav.home': 'Home',
    'nav.profile': 'Profile',
    'nav.settings': 'Settings',
    'nav.login': 'Login',
    'nav.register': 'Register',
    'nav.logout': 'Logout',
    'nav.back': 'Back',
    'nav.close': 'Close',

    // Home
    'home.title': 'Offline Web App',
    'home.welcome': 'Welcome!',
    'home.description': 'This web app works offline and has an automatic update system.',
    'home.offline_ready': 'App is ready for offline use',
    'home.update_available': 'Update available',
    'home.cached_content': 'Cached content',
    'home.pages': 'pages',
    'home.assets': 'assets',

    // Profile
    'profile.title': 'User Profile',
    'profile.info': 'User Information',
    'profile.username': 'Username',
    'profile.email': 'Email',
    'profile.created': 'Registration Date',
    'profile.lastLogin': 'Last Login',
    'profile.edit': 'Edit Profile',
    'profile.changePassword': 'Change Password',
    'profile.save': 'Save',
    'profile.cancel': 'Cancel',

    // Settings
    'settings.title': 'Settings',
    'settings.appearance': 'Appearance',
    'settings.theme': 'Theme',
    'settings.theme.dark': 'Dark',
    'settings.theme.light': 'Light',
    'settings.theme.auto': 'Auto',
    'settings.language': 'Language',
    'settings.fontSize': 'Font Size',
    'settings.fontSize.small': 'Small',
    'settings.fontSize.medium': 'Medium',
    'settings.fontSize.large': 'Large',

    'settings.notifications': 'Notifications',
    'settings.notifications.enable': 'Enable notifications',
    'settings.notifications.description': 'Receive notifications about new versions',

    'settings.updates': 'Updates',
    'settings.autoUpdate': 'Auto-check for updates',
    'settings.updateInterval': 'Check interval',
    'settings.checkUpdate': 'Check for updates',
    'settings.checking': 'Checking...',
    'settings.updateHistory': 'Update history',

    'settings.network': 'Network',
    'settings.dataSaver': 'Data saver mode',
    'settings.dataSaver.description': 'Reduces data usage',
    'settings.offlineMode': 'Offline mode',
    'settings.offlineMode.description': 'Work only with cached content',
    'settings.cache': 'Cache',
    'settings.cache.clear': 'Clear cache',
    'settings.cache.size': 'Cache size',

    'settings.security': 'Security',
    'settings.security.encryption': 'Data encryption',
    'settings.security.encrypted': 'Data is encrypted',

    'settings.reset': 'Reset settings',
    'settings.about': 'About',
    'settings.version': 'Version',

    // Update
    'update.title': 'Update',
    'update.checking': 'Checking for updates...',
    'update.noUpdates': 'No updates',
    'update.noUpdates.message': 'You have the latest version.',
    'update.available': 'Update available',
    'update.version': 'Version',
    'update.size': 'Size',
    'update.releaseDate': 'Release date',
    'update.changelog': 'What\'s new',
    'update.start': 'Start update',
    'update.downloading': 'Downloading...',
    'update.installing': 'Installing...',
    'update.completed': 'Download completed',
    'update.completed.message': 'The app will be restarted.',
    'update.restart': 'Restart',
    'update.error': 'Update error',
    'update.retry': 'Retry',

    // History
    'history.title': 'Update History',
    'history.empty': 'History is empty',
    'history.version': 'Version',
    'history.date': 'Date',
    'history.size': 'Size',
    'history.status': 'Status',
    'history.status.success': 'Success',
    'history.status.failed': 'Failed',

    // Auth
    'auth.login.title': 'Sign In',
    'auth.login.username': 'Username',
    'auth.login.password': 'Password',
    'auth.login.submit': 'Sign In',
    'auth.login.forgot': 'Forgot password?',
    'auth.login.noAccount': 'Don\'t have an account?',
    'auth.login.register': 'Register',

    'auth.register.title': 'Register',
    'auth.register.username': 'Username',
    'auth.register.email': 'Email',
    'auth.register.password': 'Password',
    'auth.register.confirmPassword': 'Confirm password',
    'auth.register.submit': 'Register',
    'auth.register.hasAccount': 'Already have an account?',
    'auth.register.login': 'Sign In',

    'auth.error.invalidCredentials': 'Invalid username or password',
    'auth.error.userExists': 'User already exists',
    'auth.error.passwordMismatch': 'Passwords do not match',
    'auth.error.required': 'Required field',

    // Network
    'network.offline': 'No internet',
    'network.offline.message': 'Check your internet connection',
    'network.online': 'Connected',

    // Common
    'common.loading': 'Loading...',
    'common.save': 'Save',
    'common.cancel': 'Cancel',
    'common.delete': 'Delete',
    'common.edit': 'Edit',
    'common.close': 'Close',
    'common.confirm': 'Confirm',
    'common.yes': 'Yes',
    'common.no': 'No',
    'common.success': 'Success',
    'common.error': 'Error',
    'common.warning': 'Warning',
    'common.info': 'Info'
  },

  kk: {
    'nav.home': 'Басты бет',
    'nav.profile': 'Профиль',
    'nav.settings': 'Параметрлер',
    'nav.login': 'Кіру',
    'nav.register': 'Тіркелу',
    'nav.logout': 'Шығу',

    'home.title': 'Оффлайн Веб-Қосымша',
    'home.welcome': 'Қош келдіңіз!',

    'settings.title': 'Параметрлер',
    'settings.theme': 'Тақырып',
    'settings.theme.dark': 'Қараңғы',
    'settings.theme.light': 'Жарық',
    'settings.language': 'Тіл',

    'update.title': 'Жаңарту',
    'update.noUpdates': 'Жаңартулар жоқ',
    'update.available': 'Жаңарту қолжетімді',
    'update.start': 'Жаңартуды бастау',

    'profile.title': 'Жеке профиль',

    'common.loading': 'Жүктелуде...',
    'common.save': 'Сақтау',
    'common.cancel': 'Болдырмау'
  },

  de: {
    'nav.home': 'Startseite',
    'nav.profile': 'Profil',
    'nav.settings': 'Einstellungen',
    'nav.login': 'Anmelden',
    'nav.register': 'Registrieren',
    'nav.logout': 'Abmelden',

    'home.title': 'Offline Web-App',
    'home.welcome': 'Willkommen!',

    'settings.title': 'Einstellungen',
    'settings.theme': 'Thema',
    'settings.theme.dark': 'Dunkel',
    'settings.theme.light': 'Hell',
    'settings.language': 'Sprache',

    'update.title': 'Update',
    'update.noUpdates': 'Keine Updates',
    'update.available': 'Update verfügbar',
    'update.start': 'Update starten',

    'profile.title': 'Benutzerprofil',

    'common.loading': 'Laden...',
    'common.save': 'Speichern',
    'common.cancel': 'Abbrechen'
  },

  fr: {
    'nav.home': 'Accueil',
    'nav.profile': 'Profil',
    'nav.settings': 'Paramètres',
    'nav.login': 'Connexion',
    'nav.register': 'Inscription',
    'nav.logout': 'Déconnexion',

    'home.title': 'Application Web Hors Ligne',
    'home.welcome': 'Bienvenue!',

    'settings.title': 'Paramètres',
    'settings.theme': 'Thème',
    'settings.theme.dark': 'Sombre',
    'settings.theme.light': 'Clair',
    'settings.language': 'Langue',

    'update.title': 'Mise à jour',
    'update.noUpdates': 'Pas de mises à jour',
    'update.available': 'Mise à jour disponible',
    'update.start': 'Démarrer la mise à jour',

    'profile.title': 'Profil utilisateur',

    'common.loading': 'Chargement...',
    'common.save': 'Enregistrer',
    'common.cancel': 'Annuler'
  },

  es: {
    'nav.home': 'Inicio',
    'nav.profile': 'Perfil',
    'nav.settings': 'Configuración',
    'nav.login': 'Iniciar sesión',
    'nav.register': 'Registrarse',
    'nav.logout': 'Cerrar sesión',

    'home.title': 'Aplicación Web Offline',
    'home.welcome': '¡Bienvenido!',

    'settings.title': 'Configuración',
    'settings.theme': 'Tema',
    'settings.theme.dark': 'Oscuro',
    'settings.theme.light': 'Claro',
    'settings.language': 'Idioma',

    'update.title': 'Actualización',
    'update.noUpdates': 'No hay actualizaciones',
    'update.available': 'Actualización disponible',
    'update.start': 'Iniciar actualización',

    'profile.title': 'Perfil de usuario',

    'common.loading': 'Cargando...',
    'common.save': 'Guardar',
    'common.cancel': 'Cancelar'
  },

  zh: {
    'nav.home': '首页',
    'nav.profile': '个人资料',
    'nav.settings': '设置',
    'nav.login': '登录',
    'nav.register': '注册',
    'nav.logout': '退出',

    'home.title': '离线网页应用',
    'home.welcome': '欢迎！',

    'settings.title': '设置',
    'settings.theme': '主题',
    'settings.theme.dark': '深色',
    'settings.theme.light': '浅色',
    'settings.language': '语言',

    'update.title': '更新',
    'update.noUpdates': '没有更新',
    'update.available': '有可用更新',
    'update.start': '开始更新',

    'profile.title': '用户资料',

    'common.loading': '加载中...',
    'common.save': '保存',
    'common.cancel': '取消'
  },

  ja: {
    'nav.home': 'ホーム',
    'nav.profile': 'プロフィール',
    'nav.settings': '設定',
    'nav.login': 'ログイン',
    'nav.register': '登録',
    'nav.logout': 'ログアウト',

    'home.title': 'オフラインWebアプリ',
    'home.welcome': 'ようこそ！',

    'settings.title': '設定',
    'settings.theme': 'テーマ',
    'settings.theme.dark': 'ダーク',
    'settings.theme.light': 'ライト',
    'settings.language': '言語',

    'update.title': 'アップデート',
    'update.noUpdates': 'アップデートなし',
    'update.available': 'アップデートあり',
    'update.start': 'アップデート開始',

    'profile.title': 'ユーザープロフィール',

    'common.loading': '読み込み中...',
    'common.save': '保存',
    'common.cancel': 'キャンセル'
  }
};

// Get translation
export function t(key: string, language: string = 'ru'): string {
  const langTranslations = translations[language] || translations['ru'];
  return langTranslations[key] || key;
}

// Get nested translation with fallback
export function translate(key: string, language: string = 'ru', fallback: string = ''): string {
  const result = t(key, language);
  return result === key ? fallback || key : result;
}

// Format translation with variables
export function formatTranslation(key: string, language: string = 'ru', vars: Record<string, string> = {}): string {
  let translation = t(key, language);
  
  Object.entries(vars).forEach(([key, value]) => {
    translation = translation.replace(`{${key}}`, value);
  });
  
  return translation;
}

// Format bytes to human readable
export function formatBytes(bytes: number, decimals: number = 2): string {
  if (bytes === 0) return '0 Bytes';

  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];

  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

// Format speed
export function formatSpeed(bytesPerSecond: number): string {
  return formatBytes(bytesPerSecond) + '/s';
}
