// Website updater utilities

import type { UpdateInfo, UpdateProgress, UpdateHistory, CachedPage, CachedAsset } from '@/types';
import { pagesDB, assetsDB, historyDB } from '@/utils/db';
import { fetchContent, extractResources, downloadFile } from '@/utils/network';
import { generateId } from '@/utils/crypto';

const TARGET_WEBSITE = 'https://sites.google.com/view/uzakbaevnurzhan/';
const MAX_PAGES = 100;

// Check for updates
export async function checkForUpdates(): Promise<UpdateInfo | null> {
  try {
    // Fetch the main page
    const content = await fetchContent(TARGET_WEBSITE);
    if (!content) {
      throw new Error('Failed to fetch target website');
    }

    // Get current cached version
    const cachedPage = await pagesDB.get(TARGET_WEBSITE) as CachedPage | null;
    
    // Calculate content hash (simple version)
    const contentHash = await calculateHash(content);
    const cachedHash = cachedPage ? await calculateHash(cachedPage.content) : null;

    if (contentHash === cachedHash) {
      return null; // No updates
    }

    // Estimate size
    const { stylesheets, scripts, images } = extractResources(content, TARGET_WEBSITE);
    const estimatedSize = await estimateTotalSize([TARGET_WEBSITE, ...stylesheets, ...scripts, ...images]);

    return {
      version: `v${Date.now()}`,
      releaseDate: new Date().toISOString(),
      changelog: ['Обновление контента сайта', `Новых страниц: ${stylesheets.length + scripts.length + images.length}`],
      size: estimatedSize,
      required: true
    };
  } catch (error) {
    console.error('Update check failed:', error);
    throw error;
  }
}

// Download and cache website
export async function downloadWebsite(
  onProgress?: (progress: UpdateProgress) => void
): Promise<boolean> {
  const updateProgress = (status: UpdateProgress['status'], progress: number, message: string, error?: string) => {
    onProgress?.({ status, progress, message, error });
  };

  try {
    updateProgress('downloading', 0, 'Начало загрузки...');

    // Clear old cache
    updateProgress('downloading', 5, 'Очистка старого кэша...');
    await clearOldCache();

    // Crawl website
    updateProgress('downloading', 10, 'Анализ сайта...');
    const pages = await crawlWebsite(TARGET_WEBSITE, MAX_PAGES, (url) => {
      updateProgress('downloading', 15, `Найдена страница: ${url}`);
    });

    if (pages.length === 0) {
      throw new Error('No pages found to download');
    }

    // Download all pages
    const totalItems = pages.length;
    let completedItems = 0;

    for (const pageUrl of pages) {
      updateProgress('downloading', 15 + (completedItems / totalItems) * 70, `Загрузка: ${pageUrl}`);

      const content = await fetchContent(pageUrl);
      if (content) {
        // Save page
        await pagesDB.save({
          url: pageUrl,
          content,
          timestamp: Date.now(),
          size: new Blob([content]).size
        });

        // Extract and download resources
        const { stylesheets, scripts, images } = extractResources(content, pageUrl);
        await downloadResources([...stylesheets, ...scripts, ...images], (loaded, total, url) => {
          const resourceProgress = (loaded / total) * (70 / totalItems);
          updateProgress(
            'downloading',
            15 + (completedItems / totalItems) * 70 + resourceProgress,
            `Загрузка ресурса: ${url}`
          );
        });
      }

      completedItems++;
    }

    // Save update history
    updateProgress('installing', 90, 'Установка обновления...');
    await saveUpdateHistory(pages.length);

    updateProgress('completed', 100, 'Загрузка завершена!');
    return true;
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    updateProgress('error', 0, 'Ошибка загрузки', errorMessage);
    return false;
  }
}

// Download resources
async function downloadResources(
  urls: string[],
  onProgress?: (loaded: number, total: number, url: string) => void
): Promise<void> {
  const uniqueUrls = [...new Set(urls)];
  const batchSize = 5;

  for (let i = 0; i < uniqueUrls.length; i += batchSize) {
    const batch = uniqueUrls.slice(i, i + batchSize);
    
    await Promise.all(
      batch.map(async (url) => {
        try {
          const blob = await downloadFile(url, (loaded, total) => {
            onProgress?.(loaded, total, url);
          });

          if (blob) {
            const type = getResourceType(url);
            await assetsDB.save({
              url,
              type,
              blob,
              timestamp: Date.now(),
              size: blob.size
            });
          }
        } catch (error) {
          console.error('Failed to download resource:', url, error);
        }
      })
    );
  }
}

// Get resource type from URL
function getResourceType(url: string): CachedAsset['type'] {
  const extension = url.split('.').pop()?.toLowerCase();
  
  if (['css'].includes(extension || '')) return 'css';
  if (['js', 'mjs'].includes(extension || '')) return 'js';
  if (['png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'ico'].includes(extension || '')) return 'image';
  
  return 'other';
}

// Clear old cache
async function clearOldCache(): Promise<void> {
  await Promise.all([
    pagesDB.clear(),
    assetsDB.clear()
  ]);
}

// Save update history
async function saveUpdateHistory(pagesCount: number): Promise<void> {
  const stats = await getDownloadStats();
  
  const history: UpdateHistory = {
    id: generateId(),
    version: `v${Date.now()}`,
    date: Date.now(),
    status: 'success',
    size: stats.totalSize
  };

  await historyDB.save(history);
}

// Get download statistics
export async function getDownloadStats(): Promise<{
  pagesCount: number;
  assetsCount: number;
  totalSize: number;
}> {
  const [pages, assets] = await Promise.all([
    pagesDB.getAll(),
    assetsDB.getAll()
  ]);

  const pagesSize = pages.reduce((sum: number, p: any) => sum + (p.size || 0), 0);
  const assetsSize = assets.reduce((sum: number, a: any) => sum + (a.size || 0), 0);

  return {
    pagesCount: pages.length,
    assetsCount: assets.length,
    totalSize: pagesSize + assetsSize
  };
}

// Get update history
export async function getUpdateHistory(): Promise<UpdateHistory[]> {
  return historyDB.getRecent(20) as Promise<UpdateHistory[]>;
}

// Calculate simple hash
async function calculateHash(content: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(content);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// Estimate total size
async function estimateTotalSize(urls: string[]): Promise<number> {
  // Rough estimate: 100KB per URL on average
  return urls.length * 100 * 1024;
}

// Crawl website pages
async function crawlWebsite(
  startUrl: string,
  maxPages: number,
  onPageFound?: (url: string) => void
): Promise<string[]> {
  const visited = new Set<string>();
  const toVisit = [startUrl];
  const baseDomain = new URL(startUrl).hostname;

  while (toVisit.length > 0 && visited.size < maxPages) {
    const url = toVisit.shift()!;
    
    if (visited.has(url)) {
      continue;
    }

    try {
      const content = await fetchContent(url);
      if (content) {
        visited.add(url);
        onPageFound?.(url);

        const { links } = extractResources(content, url);
        
        for (const link of links) {
          try {
            const linkDomain = new URL(link).hostname;
            if (linkDomain === baseDomain && !visited.has(link) && !toVisit.includes(link)) {
              toVisit.push(link);
            }
          } catch {
            // Invalid URL, skip
          }
        }
      }
    } catch (error) {
      console.error('Failed to crawl:', url, error);
    }
  }

  return Array.from(visited);
}

// Get cached page content
export async function getCachedPage(url: string): Promise<string | null> {
  const page = await pagesDB.get(url) as CachedPage | null;
  return page?.content || null;
}

// Get all cached pages
export async function getAllCachedPages(): Promise<CachedPage[]> {
  return pagesDB.getAll() as Promise<CachedPage[]>;
}

// Check if content is cached
export async function isContentCached(url: string = TARGET_WEBSITE): Promise<boolean> {
  const page = await pagesDB.get(url);
  return !!page;
}

// Get last update time
export async function getLastUpdateTime(): Promise<number | null> {
  const history = await historyDB.getRecent(1) as UpdateHistory[];
  return history.length > 0 ? history[0].date : null;
}
