// IndexedDB utilities for local storage

const DB_NAME = 'OfflineWebAppDB';
const DB_VERSION = 1;

// Database stores
const STORES = {
  USERS: 'users',
  SETTINGS: 'settings',
  PAGES: 'pages',
  ASSETS: 'assets',
  HISTORY: 'history',
  NOTIFICATIONS: 'notifications',
  SESSION: 'session'
} as const;

let dbInstance: IDBDatabase | null = null;

// Initialize database
export async function initDB(): Promise<IDBDatabase> {
  if (dbInstance) return dbInstance;

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      dbInstance = request.result;
      resolve(request.result);
    };

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;

      // Users store
      if (!db.objectStoreNames.contains(STORES.USERS)) {
        const userStore = db.createObjectStore(STORES.USERS, { keyPath: 'id' });
        userStore.createIndex('username', 'username', { unique: true });
        userStore.createIndex('email', 'email', { unique: true });
      }

      // Settings store
      if (!db.objectStoreNames.contains(STORES.SETTINGS)) {
        db.createObjectStore(STORES.SETTINGS, { keyPath: 'userId' });
      }

      // Pages store for offline content
      if (!db.objectStoreNames.contains(STORES.PAGES)) {
        const pageStore = db.createObjectStore(STORES.PAGES, { keyPath: 'url' });
        pageStore.createIndex('timestamp', 'timestamp', { unique: false });
      }

      // Assets store
      if (!db.objectStoreNames.contains(STORES.ASSETS)) {
        const assetStore = db.createObjectStore(STORES.ASSETS, { keyPath: 'url' });
        assetStore.createIndex('type', 'type', { unique: false });
        assetStore.createIndex('timestamp', 'timestamp', { unique: false });
      }

      // Update history store
      if (!db.objectStoreNames.contains(STORES.HISTORY)) {
        const historyStore = db.createObjectStore(STORES.HISTORY, { keyPath: 'id' });
        historyStore.createIndex('date', 'date', { unique: false });
      }

      // Notifications store
      if (!db.objectStoreNames.contains(STORES.NOTIFICATIONS)) {
        const notifStore = db.createObjectStore(STORES.NOTIFICATIONS, { keyPath: 'id' });
        notifStore.createIndex('timestamp', 'timestamp', { unique: false });
        notifStore.createIndex('read', 'read', { unique: false });
      }

      // Session store
      if (!db.objectStoreNames.contains(STORES.SESSION)) {
        db.createObjectStore(STORES.SESSION, { keyPath: 'key' });
      }
    };
  });
}

// Generic CRUD operations
export async function get<T>(storeName: string, key: string): Promise<T | null> {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readonly');
    const store = transaction.objectStore(storeName);
    const request = store.get(key);

    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error);
  });
}

export async function put<T>(storeName: string, value: T): Promise<void> {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readwrite');
    const store = transaction.objectStore(storeName);
    const request = store.put(value);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function remove(storeName: string, key: string): Promise<void> {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readwrite');
    const store = transaction.objectStore(storeName);
    const request = store.delete(key);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function getAll<T>(storeName: string): Promise<T[]> {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readonly');
    const store = transaction.objectStore(storeName);
    const request = store.getAll();

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function clearStore(storeName: string): Promise<void> {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readwrite');
    const store = transaction.objectStore(storeName);
    const request = store.clear();

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

// User operations
export const userDB = {
  async get(userId: string) {
    return get(STORES.USERS, userId);
  },

  async getByUsername(username: string) {
    const db = await initDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORES.USERS, 'readonly');
      const store = transaction.objectStore(STORES.USERS);
      const index = store.index('username');
      const request = index.get(username);

      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  },

  async save(user: any) {
    return put(STORES.USERS, user);
  },

  async delete(userId: string) {
    return remove(STORES.USERS, userId);
  },

  async getAll() {
    return getAll(STORES.USERS);
  }
};

// Settings operations
export const settingsDB = {
  async get(userId: string) {
    return get(STORES.SETTINGS, userId);
  },

  async save(userId: string, settings: any) {
    return put(STORES.SETTINGS, { userId, ...settings });
  },

  async delete(userId: string) {
    return remove(STORES.SETTINGS, userId);
  }
};

// Pages operations
export const pagesDB = {
  async get(url: string) {
    return get(STORES.PAGES, url);
  },

  async save(page: any) {
    return put(STORES.PAGES, page);
  },

  async delete(url: string) {
    return remove(STORES.PAGES, url);
  },

  async getAll() {
    return getAll(STORES.PAGES);
  },

  async clear() {
    return clearStore(STORES.PAGES);
  },

  async getByTimestamp() {
    const db = await initDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORES.PAGES, 'readonly');
      const store = transaction.objectStore(STORES.PAGES);
      const index = store.index('timestamp');
      const request = index.openCursor(null, 'prev');

      const results: any[] = [];
      request.onsuccess = (event) => {
        const cursor = (event.target as IDBRequest).result;
        if (cursor) {
          results.push(cursor.value);
          cursor.continue();
        } else {
          resolve(results);
        }
      };
      request.onerror = () => reject(request.error);
    });
  }
};

// Assets operations
export const assetsDB = {
  async get(url: string) {
    return get(STORES.ASSETS, url);
  },

  async save(asset: any) {
    return put(STORES.ASSETS, asset);
  },

  async delete(url: string) {
    return remove(STORES.ASSETS, url);
  },

  async getAll() {
    return getAll(STORES.ASSETS);
  },

  async clear() {
    return clearStore(STORES.ASSETS);
  },

  async getByType(type: string) {
    const db = await initDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORES.ASSETS, 'readonly');
      const store = transaction.objectStore(STORES.ASSETS);
      const index = store.index('type');
      const request = index.getAll(type);

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
};

// History operations
export const historyDB = {
  async get(id: string) {
    return get(STORES.HISTORY, id);
  },

  async save(record: any) {
    return put(STORES.HISTORY, record);
  },

  async delete(id: string) {
    return remove(STORES.HISTORY, id);
  },

  async getAll() {
    return getAll(STORES.HISTORY);
  },

  async clear() {
    return clearStore(STORES.HISTORY);
  },

  async getRecent(limit: number = 10) {
    const db = await initDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORES.HISTORY, 'readonly');
      const store = transaction.objectStore(STORES.HISTORY);
      const index = store.index('date');
      const request = index.openCursor(null, 'prev');

      const results: any[] = [];
      request.onsuccess = (event) => {
        const cursor = (event.target as IDBRequest).result;
        if (cursor && results.length < limit) {
          results.push(cursor.value);
          cursor.continue();
        } else {
          resolve(results);
        }
      };
      request.onerror = () => reject(request.error);
    });
  }
};

// Notifications operations
export const notificationsDB = {
  async get(id: string) {
    return get(STORES.NOTIFICATIONS, id);
  },

  async save(notification: any) {
    return put(STORES.NOTIFICATIONS, notification);
  },

  async delete(id: string) {
    return remove(STORES.NOTIFICATIONS, id);
  },

  async getAll() {
    return getAll(STORES.NOTIFICATIONS);
  },

  async getUnread() {
    const db = await initDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORES.NOTIFICATIONS, 'readonly');
      const store = transaction.objectStore(STORES.NOTIFICATIONS);
      const index = store.index('read');
      const request = index.getAll(0);

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  },

  async markAllAsRead() {
    const notifications = await this.getAll() as any[];
    const promises = notifications
      .filter(n => !n.read)
      .map(n => this.save({ ...n, read: true }));
    return Promise.all(promises);
  },

  async clear() {
    return clearStore(STORES.NOTIFICATIONS);
  }
};

// Session operations
export const sessionDB = {
  async get(key: string) {
    return get(STORES.SESSION, key);
  },

  async set(key: string, value: any) {
    return put(STORES.SESSION, { key, value, timestamp: Date.now() });
  },

  async remove(key: string) {
    return remove(STORES.SESSION, key);
  },

  async clear() {
    return clearStore(STORES.SESSION);
  }
};

// Get database statistics
export async function getDBStats(): Promise<{
  pages: number;
  assets: number;
  totalSize: number;
}> {
  const [pages, assets] = await Promise.all([
    pagesDB.getAll(),
    assetsDB.getAll()
  ]);

  const pagesSize = pages.reduce((sum: number, p: any) => sum + (p.size || 0), 0);
  const assetsSize = assets.reduce((sum: number, a: any) => sum + (a.size || 0), 0);

  return {
    pages: pages.length,
    assets: assets.length,
    totalSize: pagesSize + assetsSize
  };
}

// Clear all data
export async function clearAllData(): Promise<void> {
  await Promise.all([
    clearStore(STORES.PAGES),
    clearStore(STORES.ASSETS),
    clearStore(STORES.HISTORY),
    clearStore(STORES.NOTIFICATIONS),
    clearStore(STORES.SESSION)
  ]);
}
