// Service Worker utilities

// Register Service Worker
export async function registerServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if (!('serviceWorker' in navigator)) {
    console.warn('Service Worker not supported');
    return null;
  }

  try {
    const registration = await navigator.serviceWorker.register('/sw.js', {
      scope: '/'
    });

    console.log('Service Worker registered:', registration.scope);

    // Handle updates
    registration.addEventListener('updatefound', () => {
      const newWorker = registration.installing;
      if (newWorker) {
        newWorker.addEventListener('statechange', () => {
          if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
            // New version available
            window.dispatchEvent(new CustomEvent('sw-update-available'));
          }
        });
      }
    });

    return registration;
  } catch (error) {
    console.error('Service Worker registration failed:', error);
    return null;
  }
}

// Unregister Service Worker
export async function unregisterServiceWorker(): Promise<boolean> {
  if (!('serviceWorker' in navigator)) {
    return false;
  }

  try {
    const registration = await navigator.serviceWorker.ready;
    const result = await registration.unregister();
    console.log('Service Worker unregistered:', result);
    return result;
  } catch (error) {
    console.error('Service Worker unregistration failed:', error);
    return false;
  }
}

// Send message to Service Worker
export async function sendMessageToSW(type: string, payload?: any): Promise<any> {
  if (!('serviceWorker' in navigator) || !navigator.serviceWorker.controller) {
    console.warn('Service Worker not active');
    return null;
  }

  return new Promise((resolve) => {
    const channel = new MessageChannel();
    
    channel.port1.onmessage = (event) => {
      resolve(event.data);
    };

    navigator.serviceWorker.controller!.postMessage(
      { type, payload },
      [channel.port2]
    );
  });
}

// Skip waiting and activate new Service Worker
export async function skipWaiting(): Promise<void> {
  await sendMessageToSW('SKIP_WAITING');
}

// Cache URLs through Service Worker
export async function cacheUrls(urls: string[]): Promise<any> {
  return sendMessageToSW('CACHE_URLS', { urls });
}

// Clear all caches
export async function clearCaches(): Promise<any> {
  return sendMessageToSW('CLEAR_CACHE');
}

// Get cache size
export async function getCacheSize(): Promise<number> {
  const response = await sendMessageToSW('GET_CACHE_SIZE');
  return response?.size || 0;
}

// Check if app is installed (PWA)
export function isPWA(): boolean {
  return window.matchMedia('(display-mode: standalone)').matches ||
         (window.navigator as any).standalone === true;
}

// Request background sync
export async function requestBackgroundSync(tag: string = 'background-sync'): Promise<boolean> {
  if (!('serviceWorker' in navigator)) {
    console.warn('Background Sync not supported');
    return false;
  }

  try {
    const registration = await navigator.serviceWorker.ready;
    if (!('sync' in registration)) {
      console.warn('Sync not supported');
      return false;
    }
    await (registration as any).sync.register(tag);
    return true;
  } catch (error) {
    console.error('Background Sync registration failed:', error);
    return false;
  }
}

// Request periodic background sync
export async function requestPeriodicSync(tag: string = 'update-check', minInterval?: number): Promise<boolean> {
  if (!('serviceWorker' in navigator)) {
    console.warn('Periodic Background Sync not supported');
    return false;
  }

  try {
    const registration = await navigator.serviceWorker.ready;
    if (!('periodicSync' in registration)) {
      console.warn('Periodic Sync not supported');
      return false;
    }
    
    const periodicSync = (registration as any).periodicSync;
    
    // Check permission
    const status = await navigator.permissions.query({
      name: 'periodic-background-sync' as any
    });
    
    if (status.state === 'granted') {
      await periodicSync.register(tag, { minInterval });
      return true;
    }
    
    return false;
  } catch (error) {
    console.error('Periodic Sync registration failed:', error);
    return false;
  }
}

// Listen for Service Worker messages
export function listenToSWMessages(callback: (message: any) => void): () => void {
  const handler = (event: MessageEvent) => {
    callback(event.data);
  };

  navigator.serviceWorker.addEventListener('message', handler);

  // Return unsubscribe function
  return () => {
    navigator.serviceWorker.removeEventListener('message', handler);
  };
}

// Check for Service Worker updates
export async function checkForSWUpdate(): Promise<boolean> {
  if (!('serviceWorker' in navigator)) {
    return false;
  }

  try {
    const registration = await navigator.serviceWorker.ready;
    await registration.update();
    
    // Check if there's a waiting worker
    if (registration.waiting) {
      window.dispatchEvent(new CustomEvent('sw-update-available'));
      return true;
    }
    
    return false;
  } catch (error) {
    console.error('Update check failed:', error);
    return false;
  }
}
