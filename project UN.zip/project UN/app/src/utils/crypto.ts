// Encryption utilities using Web Crypto API

const ALGORITHM = 'AES-GCM';
const KEY_LENGTH = 256;
const IV_LENGTH = 12;
const SALT_LENGTH = 16;
const ITERATIONS = 100000;

// Generate a key from password
async function deriveKey(password: string, salt: Uint8Array): Promise<CryptoKey> {
  const encoder = new TextEncoder();
  const passwordBuffer = encoder.encode(password);

  // Import password as key material
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    passwordBuffer,
    'PBKDF2',
    false,
    ['deriveBits', 'deriveKey']
  );

  // Derive actual key using PBKDF2
  return crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: salt as BufferSource,
      iterations: ITERATIONS,
      hash: 'SHA-256'
    },
    keyMaterial,
    {
      name: ALGORITHM,
      length: KEY_LENGTH
    },
    false,
    ['encrypt', 'decrypt']
  );
}

// Encrypt data
export async function encryptData(data: string, password: string): Promise<{ iv: string; data: string; salt: string }> {
  try {
    const encoder = new TextEncoder();
    const dataBuffer = encoder.encode(data);

    // Generate random salt and IV
    const salt = crypto.getRandomValues(new Uint8Array(SALT_LENGTH));
    const iv = crypto.getRandomValues(new Uint8Array(IV_LENGTH));

    // Derive key from password
    const key = await deriveKey(password, salt);

    // Encrypt data
    const encryptedBuffer = await crypto.subtle.encrypt(
      {
        name: ALGORITHM,
        iv: iv
      },
      key,
      dataBuffer
    );

    // Convert to base64
    const encryptedArray = new Uint8Array(encryptedBuffer);
    
    return {
      iv: arrayBufferToBase64(iv),
      data: arrayBufferToBase64(encryptedArray),
      salt: arrayBufferToBase64(salt)
    };
  } catch (error) {
    console.error('Encryption error:', error);
    throw new Error('Failed to encrypt data');
  }
}

// Decrypt data
export async function decryptData(encryptedData: { iv: string; data: string; salt: string }, password: string): Promise<string> {
  try {
    // Decode from base64
    const iv = base64ToArrayBuffer(encryptedData.iv);
    const data = base64ToArrayBuffer(encryptedData.data);
    const salt = base64ToArrayBuffer(encryptedData.salt);

    // Derive key from password
    const key = await deriveKey(password, new Uint8Array(salt) as any);

    // Decrypt data
    const decryptedBuffer = await crypto.subtle.decrypt(
      {
        name: ALGORITHM,
        iv: new Uint8Array(iv) as any
      },
      key,
      new Uint8Array(data) as any
    );

    // Convert to string
    const decoder = new TextDecoder();
    return decoder.decode(decryptedBuffer);
  } catch (error) {
    console.error('Decryption error:', error);
    throw new Error('Failed to decrypt data - invalid password or corrupted data');
  }
}

// Hash password for storage
export async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  return arrayBufferToBase64(hashBuffer);
}

// Verify password
export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  const hash = await hashPassword(password);
  return hash === hashedPassword;
}

// Generate random ID
export function generateId(): string {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
}

// Generate secure token
export function generateToken(length: number = 32): string {
  const array = new Uint8Array(length);
  crypto.getRandomValues(array);
  return arrayBufferToBase64(array);
}

// Helper functions
function arrayBufferToBase64(buffer: Uint8Array | ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

// Encrypt user data object
export async function encryptUserData(userData: any, password: string): Promise<any> {
  const sensitiveFields = ['password', 'email', 'phone', 'address'];
  const encrypted: any = { ...userData };

  for (const field of sensitiveFields) {
    if (userData[field]) {
      const encryptedField = await encryptData(userData[field], password);
      encrypted[field] = JSON.stringify(encryptedField);
    }
  }

  return encrypted;
}

// Decrypt user data object
export async function decryptUserData(encryptedData: any, password: string): Promise<any> {
  const sensitiveFields = ['password', 'email', 'phone', 'address'];
  const decrypted: any = { ...encryptedData };

  for (const field of sensitiveFields) {
    if (encryptedData[field] && typeof encryptedData[field] === 'string') {
      try {
        const parsed = JSON.parse(encryptedData[field]);
        if (parsed.iv && parsed.data && parsed.salt) {
          decrypted[field] = await decryptData(parsed, password);
        }
      } catch (e) {
        // Field might not be encrypted
        decrypted[field] = encryptedData[field];
      }
    }
  }

  return decrypted;
}
