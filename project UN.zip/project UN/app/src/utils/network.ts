// Network utilities

import type { NetworkStatus } from '@/types';

// Check online status
export function isOnline(): boolean {
  return navigator.onLine;
}

// Get network status
export function getNetworkStatus(): NetworkStatus {
  const connection = (navigator as any).connection ||
                     (navigator as any).mozConnection ||
                     (navigator as any).webkitConnection;

  return {
    online: navigator.onLine,
    type: connection?.type,
    effectiveType: connection?.effectiveType,
    downlink: connection?.downlink,
    rtt: connection?.rtt
  };
}

// Listen for network changes
export function listenToNetworkChanges(callback: (status: NetworkStatus) => void): () => void {
  const handleOnline = () => callback(getNetworkStatus());
  const handleOffline = () => callback(getNetworkStatus());
  const handleConnectionChange = () => callback(getNetworkStatus());

  window.addEventListener('online', handleOnline);
  window.addEventListener('offline', handleOffline);

  const connection = (navigator as any).connection;
  if (connection) {
    connection.addEventListener('change', handleConnectionChange);
  }

  // Return unsubscribe function
  return () => {
    window.removeEventListener('online', handleOnline);
    window.removeEventListener('offline', handleOffline);
    if (connection) {
      connection.removeEventListener('change', handleConnectionChange);
    }
  };
}

// Fetch with timeout and retry
export async function fetchWithTimeout(
  url: string,
  options: RequestInit = {},
  timeout: number = 10000,
  retries: number = 3
): Promise<Response> {
  const fetchWithTimeout = async (): Promise<Response> => {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);

    try {
      const response = await fetch(url, {
        ...options,
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      return response;
    } catch (error) {
      clearTimeout(timeoutId);
      throw error;
    }
  };

  let lastError: Error | undefined;

  for (let i = 0; i < retries; i++) {
    try {
      return await fetchWithTimeout();
    } catch (error) {
      lastError = error as Error;
      if (i < retries - 1) {
        // Wait before retrying (exponential backoff)
        await new Promise(resolve => setTimeout(resolve, Math.pow(2, i) * 1000));
      }
    }
  }

  throw lastError;
}

// Check if URL is accessible
export async function isUrlAccessible(url: string, timeout: number = 5000): Promise<boolean> {
  try {
    const response = await fetchWithTimeout(url, { method: 'HEAD' }, timeout, 1);
    return response.ok;
  } catch {
    return false;
  }
}

// Get content from URL
export async function fetchContent(url: string): Promise<string | null> {
  try {
    const response = await fetchWithTimeout(url);
    if (response.ok) {
      return await response.text();
    }
    return null;
  } catch (error) {
    console.error('Failed to fetch content:', error);
    return null;
  }
}

// Download file with progress
export async function downloadFile(
  url: string,
  onProgress?: (loaded: number, total: number) => void
): Promise<Blob | null> {
  try {
    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const contentLength = parseInt(response.headers.get('content-length') || '0');
    const reader = response.body?.getReader();

    if (!reader) {
      throw new Error('ReadableStream not supported');
    }

    let receivedLength = 0;
    const chunks: Uint8Array[] = [];

    while (true) {
      const { done, value } = await reader.read();

      if (done) {
        break;
      }

      chunks.push(value);
      receivedLength += value.length;

      if (onProgress && contentLength) {
        onProgress(receivedLength, contentLength);
      }
    }

    // Combine chunks
    const allChunks = new Uint8Array(receivedLength);
    let position = 0;
    for (const chunk of chunks) {
      allChunks.set(chunk, position);
      position += chunk.length;
    }

    return new Blob([allChunks]);
  } catch (error) {
    console.error('Download failed:', error);
    return null;
  }
}

// Parse HTML and extract resources
export function extractResources(html: string, baseUrl: string): {
  stylesheets: string[];
  scripts: string[];
  images: string[];
  links: string[];
} {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');

  const makeAbsolute = (url: string): string => {
    try {
      return new URL(url, baseUrl).href;
    } catch {
      return url;
    }
  };

  // Extract stylesheets
  const stylesheets = Array.from(doc.querySelectorAll('link[rel="stylesheet"]'))
    .map(el => makeAbsolute((el as HTMLLinkElement).href))
    .filter(Boolean);

  // Extract scripts
  const scripts = Array.from(doc.querySelectorAll('script[src]'))
    .map(el => makeAbsolute((el as HTMLScriptElement).src))
    .filter(Boolean);

  // Extract images
  const images = Array.from(doc.querySelectorAll('img[src]'))
    .map(el => makeAbsolute((el as HTMLImageElement).src))
    .filter(Boolean);

  // Extract links
  const links = Array.from(doc.querySelectorAll('a[href]'))
    .map(el => makeAbsolute((el as HTMLAnchorElement).href))
    .filter(href => href.startsWith('http'));

  return { stylesheets, scripts, images, links };
}

// Get all pages from a website
export async function crawlWebsite(
  startUrl: string,
  maxPages: number = 50,
  onPageFound?: (url: string) => void
): Promise<string[]> {
  const visited = new Set<string>();
  const toVisit = [startUrl];
  const baseDomain = new URL(startUrl).hostname;

  while (toVisit.length > 0 && visited.size < maxPages) {
    const url = toVisit.shift()!;
    
    if (visited.has(url)) {
      continue;
    }

    try {
      const content = await fetchContent(url);
      if (content) {
        visited.add(url);
        onPageFound?.(url);

        const { links } = extractResources(content, url);
        
        // Add same-domain links to queue
        for (const link of links) {
          try {
            const linkDomain = new URL(link).hostname;
            if (linkDomain === baseDomain && !visited.has(link)) {
              toVisit.push(link);
            }
          } catch {
            // Invalid URL, skip
          }
        }
      }
    } catch (error) {
      console.error('Failed to crawl:', url, error);
    }
  }

  return Array.from(visited);
}
