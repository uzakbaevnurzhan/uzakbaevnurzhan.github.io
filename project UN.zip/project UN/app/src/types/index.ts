// Типы для пользователя
export interface User {
  id: string;
  username: string;
  email: string;
  avatar?: string;
  createdAt: number;
  lastLogin: number;
}

export interface UserCredentials {
  username: string;
  password: string;
  email?: string;
}

// Типы для настроек
export interface AppSettings {
  theme: 'dark' | 'light' | 'auto';
  language: string;
  notifications: boolean;
  fontSize: number;
  dataSaver: boolean;
  autoUpdate: boolean;
  updateInterval: number;
  offlineMode: boolean;
  lastUpdateCheck: number;
  cacheEnabled: boolean;
}

// Типы для обновлений
export interface UpdateInfo {
  version: string;
  releaseDate: string;
  changelog: string[];
  size: number;
  required: boolean;
}

export interface UpdateProgress {
  status: 'idle' | 'checking' | 'available' | 'downloading' | 'installing' | 'completed' | 'error';
  progress: number;
  message: string;
  error?: string;
}

export interface UpdateHistory {
  id: string;
  version: string;
  date: number;
  status: 'success' | 'failed';
  size: number;
}

// Типы для кэшированного контента
export interface CachedPage {
  url: string;
  content: string;
  timestamp: number;
  size: number;
}

export interface CachedAsset {
  url: string;
  type: 'image' | 'css' | 'js' | 'other';
  timestamp: number;
  size: number;
}

// Типы для уведомлений
export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  timestamp: number;
  read: boolean;
}

// Типы для языков
export interface Language {
  code: string;
  name: string;
  nativeName: string;
  flag: string;
}

// Типы для навигации
export type Route = 
  | 'home' 
  | 'profile' 
  | 'settings' 
  | 'update' 
  | 'login' 
  | 'register' 
  | 'history' 
  | 'about';

// Типы для сети
export interface NetworkStatus {
  online: boolean;
  type?: string;
  effectiveType?: string;
  downlink?: number;
  rtt?: number;
}

// Типы для шифрования
export interface EncryptedData {
  iv: string;
  data: string;
  salt: string;
}
