import { useState, useEffect, useCallback } from 'react';
import './App.css';
import { Header } from '@/components/Header';
import { BottomNav } from '@/components/BottomNav';
import { HomeScreen } from '@/components/screens/HomeScreen';
import { ProfileScreen } from '@/components/screens/ProfileScreen';
import { SettingsScreen } from '@/components/screens/SettingsScreen';
import { UpdateScreen } from '@/components/screens/UpdateScreen';
import { AuthScreen } from '@/components/screens/AuthScreen';
import { HistoryScreen } from '@/components/screens/HistoryScreen';
import { useAuth } from '@/hooks/useAuth';
import { useSettings } from '@/hooks/useSettings';
import { useNetwork } from '@/hooks/useNetwork';
import { useUpdater } from '@/hooks/useUpdater';
import type { Route, AppSettings, User } from '@/types';
import { t } from '@/i18n';
import { registerServiceWorker } from '@/utils/sw';
import { getDBStats } from '@/utils/db';
import { notificationsDB } from '@/utils/db';
import { Toaster } from '@/components/ui/sonner';
import { toast } from 'sonner';

function App() {
  // Auth state
  const { user, isAuthenticated, isLoading: authLoading, login, register, logout, updateProfile, changePassword } = useAuth();

  // Settings state
  const { settings, isLoading: settingsLoading, updateSetting, saveSettings, resetSettings } = useSettings(user?.id);

  // Network state
  const { isConnected } = useNetwork();

  // Updater state
  const { 
    updateInfo, 
    progress, 
    stats, 
    isCached,
    checkForUpdates, 
    downloadUpdate,
    refreshStats,
  } = useUpdater(settings.autoUpdate, settings.updateInterval);

  // App state
  const [currentRoute, setCurrentRoute] = useState<Route>('home');
  const [cacheSize, setCacheSize] = useState({ pages: 0, assets: 0, totalSize: 0 });
  const [unreadNotifications, setUnreadNotifications] = useState(0);

  // Initialize app
  useEffect(() => {
    const init = async () => {
      // Register Service Worker
      await registerServiceWorker();

      // Load cache size
      await loadCacheSize();

      // Load unread notifications
      await loadUnreadNotifications();

      // Check for SW updates
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.addEventListener('message', (event) => {
          if (event.data.type === 'sw-update-available') {
            toast.info('Доступно обновление приложения', {
              action: {
                label: 'Обновить',
                onClick: () => window.location.reload()
              }
            });
          }
        });
      }
    };

    init();
  }, []);

  // Load cache size
  const loadCacheSize = async () => {
    const size = await getDBStats();
    setCacheSize(size);
  };

  // Load unread notifications
  const loadUnreadNotifications = async () => {
    const unread = await notificationsDB.getUnread() as any[];
    setUnreadNotifications(unread.length);
  };

  // Handle navigation
  const handleNavigate = useCallback((route: Route) => {
    setCurrentRoute(route);
    window.scrollTo(0, 0);
  }, []);

  // Handle setting update
  const handleUpdateSetting = useCallback(<K extends keyof AppSettings>(key: K, value: AppSettings[K]) => {
    updateSetting(key, value);
  }, [updateSetting]);

  // Handle check update
  const handleCheckUpdate = useCallback(async () => {
    if (!isConnected) {
      toast.error(t('network.offline', settings.language));
      return null;
    }

    const info = await checkForUpdates();
    
    if (info) {
      toast.success(t('update.available', settings.language), {
        description: `${t('update.version', settings.language)}: ${info.version}`
      });
    } else {
      toast.info(t('update.noUpdates', settings.language));
    }

    return info;
  }, [checkForUpdates, isConnected, settings.language]);

  // Handle download update
  const handleDownloadUpdate = useCallback(async () => {
    const success = await downloadUpdate();
    
    if (success) {
      await loadCacheSize();
      await refreshStats();
      toast.success(t('update.completed', settings.language));
    } else {
      toast.error(t('update.error', settings.language));
    }

    return success;
  }, [downloadUpdate, settings.language, refreshStats]);

  // Handle clear cache
  const handleClearCache = useCallback(async () => {
    await loadCacheSize();
    await refreshStats();
    toast.success('Кэш очищен');
  }, [refreshStats]);

  // Handle login
  const handleLogin = useCallback(async (credentials: any) => {
    const result = await login(credentials);
    
    if (result.success) {
      toast.success('Успешный вход');
      handleNavigate('home');
    } else {
      toast.error(result.error);
    }

    return result;
  }, [login, handleNavigate]);

  // Handle register
  const handleRegister = useCallback(async (credentials: any) => {
    const result = await register(credentials);
    
    if (result.success) {
      toast.success('Регистрация успешна');
      handleNavigate('home');
    } else {
      toast.error(result.error);
    }

    return result;
  }, [register, handleNavigate]);

  // Handle logout
  const handleLogout = useCallback(async () => {
    await logout();
    toast.success('Вы вышли из аккаунта');
    handleNavigate('home');
  }, [logout, handleNavigate]);

  // Handle update profile
  const handleUpdateProfile = useCallback(async (updates: Partial<User>) => {
    const result = await updateProfile(updates);
    
    if (result.success) {
      toast.success('Профиль обновлен');
    } else {
      toast.error(result.error);
    }

    return result;
  }, [updateProfile]);

  // Handle change password
  const handleChangePassword = useCallback(async (oldPassword: string, newPassword: string) => {
    const result = await changePassword(oldPassword, newPassword);
    
    if (result.success) {
      toast.success('Пароль изменен');
    } else {
      toast.error(result.error);
    }

    return result;
  }, [changePassword]);

  // Handle reset settings
  const handleResetSettings = useCallback(async () => {
    await resetSettings();
    toast.success('Настройки сброшены');
  }, [resetSettings]);

  // Render current screen
  const renderScreen = () => {
    switch (currentRoute) {
      case 'home':
        return (
          <HomeScreen
            language={settings.language}
            isOnline={isConnected}
            isCached={isCached}
            stats={stats}
            updateInfo={updateInfo}
            onNavigate={handleNavigate}
            onCheckUpdate={handleCheckUpdate}
          />
        );

      case 'profile':
        return (
          <ProfileScreen
            user={user}
            isAuthenticated={isAuthenticated}
            language={settings.language}
            onUpdateProfile={handleUpdateProfile}
            onChangePassword={handleChangePassword}
            onNavigate={handleNavigate}
          />
        );

      case 'settings':
        return (
          <SettingsScreen
            settings={settings}
            language={settings.language}
            isOnline={isConnected}
            cacheSize={cacheSize}
            onUpdateSetting={handleUpdateSetting}
            onSaveSettings={saveSettings}
            onResetSettings={handleResetSettings}
            onCheckUpdate={handleCheckUpdate}
            onClearCache={handleClearCache}
            onNavigate={handleNavigate}
          />
        );

      case 'update':
        return (
          <UpdateScreen
            language={settings.language}
            isOnline={isConnected}
            updateInfo={updateInfo}
            progress={progress}
            onCheckUpdate={checkForUpdates}
            onDownload={handleDownloadUpdate}
            onBack={() => handleNavigate('home')}
          />
        );

      case 'login':
        return (
          <AuthScreen
            mode="login"
            language={settings.language}
            onLogin={handleLogin}
            onRegister={handleRegister}
            onSwitchMode={() => {
              setAuthMode('register');
              handleNavigate('register');
            }}
            onBack={() => handleNavigate('home')}
          />
        );

      case 'register':
        return (
          <AuthScreen
            mode="register"
            language={settings.language}
            onLogin={handleLogin}
            onRegister={handleRegister}
            onSwitchMode={() => {
              setAuthMode('login');
              handleNavigate('login');
            }}
            onBack={() => handleNavigate('home')}
          />
        );

      case 'history':
        return (
          <HistoryScreen
            language={settings.language}
            onBack={() => handleNavigate('settings')}
          />
        );

      default:
        return (
          <HomeScreen
            language={settings.language}
            isOnline={isConnected}
            isCached={isCached}
            stats={stats}
            updateInfo={updateInfo}
            onNavigate={handleNavigate}
            onCheckUpdate={handleCheckUpdate}
          />
        );
    }
  };

  // Show loading state
  if (authLoading || settingsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      {currentRoute !== 'login' && currentRoute !== 'register' && (
        <Header
          user={user}
          isAuthenticated={isAuthenticated}
          currentRoute={currentRoute}
          language={settings.language}
          unreadNotifications={unreadNotifications}
          onNavigate={handleNavigate}
          onLogout={handleLogout}
        />
      )}

      {/* Main Content */}
      <main className={`container mx-auto px-4 py-6 ${currentRoute === 'login' || currentRoute === 'register' ? '' : 'pt-20 pb-24'}`}>
        {renderScreen()}
      </main>

      {/* Bottom Navigation */}
      {currentRoute !== 'login' && currentRoute !== 'register' && currentRoute !== 'update' && currentRoute !== 'history' && (
        <BottomNav
          currentRoute={currentRoute}
          language={settings.language}
          onNavigate={handleNavigate}
        />
      )}

      {/* Toast notifications */}
      <Toaster 
        position="top-center"
        toastOptions={{
          style: {
            background: 'var(--background)',
            color: 'var(--foreground)',
            border: '1px solid var(--border)',
          },
        }}
      />
    </div>
  );
}

export default App;
