import { useState, useEffect, useCallback } from 'react';
import type { User, UserCredentials } from '@/types';
import { userDB, sessionDB } from '@/utils/db';
import { hashPassword, verifyPassword, generateId, generateToken } from '@/utils/crypto';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export function useAuth() {
  const [state, setState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true
  });

  // Load user from session on mount
  useEffect(() => {
    loadUserFromSession();
  }, []);

  const loadUserFromSession = async () => {
    try {
      const session = await sessionDB.get('currentUser') as { value: { userId: string } } | null;
      if (session?.value) {
        const user = await userDB.get(session.value.userId);
        if (user) {
          setState({
            user: user as User,
            isAuthenticated: true,
            isLoading: false
          });
          return;
        }
      }
    } catch (error) {
      console.error('Failed to load session:', error);
    }
    
    setState(prev => ({ ...prev, isLoading: false }));
  };

  const login = useCallback(async (credentials: UserCredentials): Promise<{ success: boolean; error?: string }> => {
    try {
      const user = await userDB.getByUsername(credentials.username) as User | null;
      
      if (!user) {
        return { success: false, error: 'Пользователь не найден' };
      }

      const isValid = await verifyPassword(credentials.password, (user as any).passwordHash);
      
      if (!isValid) {
        return { success: false, error: 'Неверный пароль' };
      }

      // Create session
      const sessionToken = generateToken();
      await sessionDB.set('currentUser', {
        userId: user.id,
        token: sessionToken,
        createdAt: Date.now()
      });

      // Update last login
      const updatedUser = { ...user, lastLogin: Date.now() };
      await userDB.save(updatedUser);

      setState({
        user: updatedUser,
        isAuthenticated: true,
        isLoading: false
      });

      return { success: true };
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, error: 'Ошибка входа' };
    }
  }, []);

  const register = useCallback(async (credentials: UserCredentials): Promise<{ success: boolean; error?: string }> => {
    try {
      // Check if username exists
      const existingUser = await userDB.getByUsername(credentials.username);
      if (existingUser) {
        return { success: false, error: 'Пользователь с таким именем уже существует' };
      }

      // Hash password
      const passwordHash = await hashPassword(credentials.password);

      // Create new user
      const newUser: User = {
        id: generateId(),
        username: credentials.username,
        email: credentials.email || '',
        createdAt: Date.now(),
        lastLogin: Date.now()
      };

      // Save user with hashed password
      await userDB.save({
        ...newUser,
        passwordHash
      });

      // Create session
      const sessionToken = generateToken();
      await sessionDB.set('currentUser', {
        userId: newUser.id,
        token: sessionToken,
        createdAt: Date.now()
      });

      setState({
        user: newUser,
        isAuthenticated: true,
        isLoading: false
      });

      return { success: true };
    } catch (error) {
      console.error('Registration error:', error);
      return { success: false, error: 'Ошибка регистрации' };
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      await sessionDB.remove('currentUser');
      setState({
        user: null,
        isAuthenticated: false,
        isLoading: false
      });
    } catch (error) {
      console.error('Logout error:', error);
    }
  }, []);

  const updateProfile = useCallback(async (updates: Partial<User>): Promise<{ success: boolean; error?: string }> => {
    try {
      if (!state.user) {
        return { success: false, error: 'Пользователь не авторизован' };
      }

      const updatedUser = { ...state.user, ...updates };
      await userDB.save(updatedUser);

      setState(prev => ({
        ...prev,
        user: updatedUser
      }));

      return { success: true };
    } catch (error) {
      console.error('Profile update error:', error);
      return { success: false, error: 'Ошибка обновления профиля' };
    }
  }, [state.user]);

  const changePassword = useCallback(async (oldPassword: string, newPassword: string): Promise<{ success: boolean; error?: string }> => {
    try {
      if (!state.user) {
        return { success: false, error: 'Пользователь не авторизован' };
      }

      const user = await userDB.get(state.user.id) as any;
      const isValid = await verifyPassword(oldPassword, user.passwordHash);

      if (!isValid) {
        return { success: false, error: 'Неверный текущий пароль' };
      }

      const newPasswordHash = await hashPassword(newPassword);
      await userDB.save({
        ...user,
        passwordHash: newPasswordHash
      });

      return { success: true };
    } catch (error) {
      console.error('Password change error:', error);
      return { success: false, error: 'Ошибка смены пароля' };
    }
  }, [state.user]);

  return {
    ...state,
    login,
    register,
    logout,
    updateProfile,
    changePassword
  };
}
