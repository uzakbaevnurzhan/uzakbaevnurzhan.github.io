import { useState, useEffect, useRef, useCallback } from 'react';
import type { UpdateInfo, UpdateProgress, UpdateHistory } from '@/types';
import { 
  checkForUpdates, 
  downloadWebsite, 
  getUpdateHistory, 
  getDownloadStats,
  getLastUpdateTime,
  isContentCached
} from '@/utils/updater';

interface UpdaterState {
  updateInfo: UpdateInfo | null;
  progress: UpdateProgress;
  history: UpdateHistory[];
  stats: {
    pagesCount: number;
    assetsCount: number;
    totalSize: number;
  };
  lastUpdateTime: number | null;
  isCached: boolean;
}

export function useUpdater(autoCheck: boolean = false, checkInterval?: number) {
  const [state, setState] = useState<UpdaterState>({
    updateInfo: null,
    progress: {
      status: 'idle',
      progress: 0,
      message: ''
    },
    history: [],
    stats: {
      pagesCount: 0,
      assetsCount: 0,
      totalSize: 0
    },
    lastUpdateTime: null,
    isCached: false
  });

  const checkIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Load initial data
  useEffect(() => {
    loadInitialData();
  }, []);

  // Auto check for updates
  useEffect(() => {
    if (autoCheck && checkInterval) {
      checkIntervalRef.current = setInterval(() => {
        handleCheckForUpdates();
      }, checkInterval);

      return () => {
        if (checkIntervalRef.current) {
          clearInterval(checkIntervalRef.current);
        }
      };
    }
  }, [autoCheck, checkInterval]);

  const loadInitialData = async () => {
    try {
      const [history, stats, lastUpdateTime, isCached] = await Promise.all([
        getUpdateHistory(),
        getDownloadStats(),
        getLastUpdateTime(),
        isContentCached()
      ]);

      setState(prev => ({
        ...prev,
        history,
        stats,
        lastUpdateTime,
        isCached
      }));
    } catch (error) {
      console.error('Failed to load initial data:', error);
    }
  };

  const handleCheckForUpdates = useCallback(async (): Promise<UpdateInfo | null> => {
    setState(prev => ({
      ...prev,
      progress: {
        status: 'checking',
        progress: 0,
        message: 'Проверка обновлений...'
      }
    }));

    try {
      const updateInfo = await checkForUpdates();

      setState(prev => ({
        ...prev,
        updateInfo,
        progress: {
          status: updateInfo ? 'available' : 'idle',
          progress: 0,
          message: updateInfo ? 'Доступно обновление' : 'Нет обновлений'
        }
      }));

      return updateInfo;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Ошибка проверки обновлений';
      
      setState(prev => ({
        ...prev,
        progress: {
          status: 'error',
          progress: 0,
          message: errorMessage,
          error: errorMessage
        }
      }));

      return null;
    }
  }, []);

  const handleDownload = useCallback(async (): Promise<boolean> => {
    setState(prev => ({
      ...prev,
      progress: {
        status: 'downloading',
        progress: 0,
        message: 'Начало загрузки...'
      }
    }));

    const success = await downloadWebsite((progress) => {
      setState(prev => ({
        ...prev,
        progress
      }));
    });

    if (success) {
      // Reload data after successful download
      await loadInitialData();
      
      // Set cached flag
      setState(prev => ({
        ...prev,
        isCached: true
      }));
    }

    return success;
  }, []);

  const refreshHistory = useCallback(async () => {
    const history = await getUpdateHistory();
    setState(prev => ({ ...prev, history }));
  }, []);

  const refreshStats = useCallback(async () => {
    const stats = await getDownloadStats();
    setState(prev => ({ ...prev, stats }));
  }, []);

  const clearUpdateInfo = useCallback(() => {
    setState(prev => ({
      ...prev,
      updateInfo: null,
      progress: {
        status: 'idle',
        progress: 0,
        message: ''
      }
    }));
  }, []);

  return {
    ...state,
    checkForUpdates: handleCheckForUpdates,
    downloadUpdate: handleDownload,
    refreshHistory,
    refreshStats,
    clearUpdateInfo
  };
}
