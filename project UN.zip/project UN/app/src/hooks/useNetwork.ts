import { useState, useEffect, useCallback } from 'react';
import type { NetworkStatus } from '@/types';
import { isOnline, getNetworkStatus, listenToNetworkChanges } from '@/utils/network';

export function useNetwork() {
  const [isConnected, setIsConnected] = useState(isOnline());
  const [networkStatus, setNetworkStatus] = useState<NetworkStatus>(getNetworkStatus());

  useEffect(() => {
    const unsubscribe = listenToNetworkChanges((status) => {
      setIsConnected(status.online);
      setNetworkStatus(status);
    });

    return unsubscribe;
  }, []);

  const checkConnection = useCallback(async (): Promise<boolean> => {
    const status = getNetworkStatus();
    setIsConnected(status.online);
    setNetworkStatus(status);
    return status.online;
  }, []);

  return {
    isConnected,
    networkStatus,
    checkConnection
  };
}
