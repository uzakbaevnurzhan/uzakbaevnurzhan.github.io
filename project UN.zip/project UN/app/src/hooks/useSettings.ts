import { useState, useEffect, useCallback } from 'react';
import type { AppSettings } from '@/types';
import { settingsDB } from '@/utils/db';

const DEFAULT_SETTINGS: AppSettings = {
  theme: 'dark',
  language: 'ru',
  notifications: true,
  fontSize: 16,
  dataSaver: false,
  autoUpdate: true,
  updateInterval: 24 * 60 * 60 * 1000, // 24 hours
  offlineMode: false,
  lastUpdateCheck: 0,
  cacheEnabled: true
};

export function useSettings(userId?: string) {
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [isLoading, setIsLoading] = useState(true);

  // Load settings on mount
  useEffect(() => {
    loadSettings();
  }, [userId]);

  const loadSettings = async () => {
    try {
      if (userId) {
        const savedSettings = await settingsDB.get(userId);
        if (savedSettings) {
          const { userId: _, ...rest } = savedSettings as any;
          setSettings(prev => ({ ...prev, ...rest }));
        }
      } else {
        // Try to load from localStorage for non-logged users
        const saved = localStorage.getItem('appSettings');
        if (saved) {
          setSettings(prev => ({ ...prev, ...JSON.parse(saved) }));
        }
      }
    } catch (error) {
      console.error('Failed to load settings:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveSettings = useCallback(async (newSettings: Partial<AppSettings>) => {
    try {
      const updated = { ...settings, ...newSettings };
      setSettings(updated);

      if (userId) {
        await settingsDB.save(userId, updated);
      } else {
        localStorage.setItem('appSettings', JSON.stringify(updated));
      }

      // Apply settings immediately
      applySettings(updated);

      return { success: true };
    } catch (error) {
      console.error('Failed to save settings:', error);
      return { success: false, error: 'Ошибка сохранения настроек' };
    }
  }, [settings, userId]);

  const updateSetting = useCallback(async <K extends keyof AppSettings>(
    key: K,
    value: AppSettings[K]
  ) => {
    return saveSettings({ [key]: value });
  }, [saveSettings]);

  const resetSettings = useCallback(async () => {
    try {
      setSettings(DEFAULT_SETTINGS);

      if (userId) {
        await settingsDB.save(userId, DEFAULT_SETTINGS);
      } else {
        localStorage.setItem('appSettings', JSON.stringify(DEFAULT_SETTINGS));
      }

      applySettings(DEFAULT_SETTINGS);

      return { success: true };
    } catch (error) {
      console.error('Failed to reset settings:', error);
      return { success: false, error: 'Ошибка сброса настроек' };
    }
  }, [userId]);

  // Apply settings to document
  const applySettings = (s: AppSettings) => {
    // Apply theme
    const root = document.documentElement;
    root.classList.remove('light', 'dark');
    
    if (s.theme === 'auto') {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      root.classList.add(prefersDark ? 'dark' : 'light');
    } else {
      root.classList.add(s.theme);
    }

    // Apply font size
    root.style.fontSize = `${s.fontSize}px`;

    // Apply language
    document.documentElement.lang = s.language;
  };

  // Apply settings on mount
  useEffect(() => {
    if (!isLoading) {
      applySettings(settings);
    }
  }, [settings, isLoading]);

  // Listen for system theme changes
  useEffect(() => {
    if (settings.theme === 'auto') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const handler = () => applySettings(settings);
      mediaQuery.addEventListener('change', handler);
      return () => mediaQuery.removeEventListener('change', handler);
    }
  }, [settings]);

  return {
    settings,
    isLoading,
    saveSettings,
    updateSetting,
    resetSettings
  };
}
