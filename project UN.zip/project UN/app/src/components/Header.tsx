import { useState } from 'react';
import { User, Settings, Bell, Menu, X, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import type { User as UserType, Route } from '@/types';
import { t } from '@/i18n';

interface HeaderProps {
  user: UserType | null;
  isAuthenticated: boolean;
  currentRoute: Route;
  language: string;
  unreadNotifications: number;
  onNavigate: (route: Route) => void;
  onLogout: () => void;
}

export function Header({
  user,
  isAuthenticated,
  currentRoute,
  language,
  unreadNotifications,
  onNavigate,
  onLogout
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const getInitials = (name: string) => {
    return name.slice(0, 2).toUpperCase();
  };

  const navItems: { route: Route; label: string; icon: React.ReactNode }[] = [
    { route: 'home', label: t('nav.home', language), icon: <Home className="w-4 h-4" /> },
    { route: 'profile', label: t('nav.profile', language), icon: <User className="w-4 h-4" /> },
    { route: 'settings', label: t('nav.settings', language), icon: <Settings className="w-4 h-4" /> },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center">
        {/* Logo */}
        <div className="mr-4 flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-sm">OA</span>
          </div>
          <span className="font-semibold hidden sm:inline">OfflineApp</span>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-1 flex-1">
          {navItems.map((item) => (
            <Button
              key={item.route}
              variant={currentRoute === item.route ? 'secondary' : 'ghost'}
              size="sm"
              onClick={() => onNavigate(item.route)}
              className="gap-2"
            >
              {item.icon}
              {item.label}
            </Button>
          ))}
        </nav>

        {/* Right side */}
        <div className="flex items-center gap-2 ml-auto">
          {/* Notifications */}
          <Button
            variant="ghost"
            size="icon"
            className="relative"
            onClick={() => onNavigate('settings')}
          >
            <Bell className="h-5 w-5" />
            {unreadNotifications > 0 && (
              <Badge 
                variant="destructive" 
                className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
              >
                {unreadNotifications}
              </Badge>
            )}
          </Button>

          {/* User Menu */}
          {isAuthenticated ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {user ? getInitials(user.username) : '?'}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <div className="flex items-center gap-2 p-2">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {user ? getInitials(user.username) : '?'}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col">
                    <p className="text-sm font-medium">{user?.username}</p>
                    <p className="text-xs text-muted-foreground">{user?.email}</p>
                  </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => onNavigate('profile')}>
                  <User className="mr-2 h-4 w-4" />
                  {t('nav.profile', language)}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onNavigate('settings')}>
                  <Settings className="mr-2 h-4 w-4" />
                  {t('nav.settings', language)}
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={onLogout}>
                  {t('nav.logout', language)}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <div className="hidden sm:flex items-center gap-2">
              <Button variant="ghost" size="sm" onClick={() => onNavigate('login')}>
                {t('nav.login', language)}
              </Button>
              <Button size="sm" onClick={() => onNavigate('register')}>
                {t('nav.register', language)}
              </Button>
            </div>
          )}

          {/* Mobile menu button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-border/40 bg-background">
          <nav className="flex flex-col p-2 space-y-1">
            {navItems.map((item) => (
              <Button
                key={item.route}
                variant={currentRoute === item.route ? 'secondary' : 'ghost'}
                size="sm"
                onClick={() => {
                  onNavigate(item.route);
                  setMobileMenuOpen(false);
                }}
                className="justify-start gap-2"
              >
                {item.icon}
                {item.label}
              </Button>
            ))}
            {!isAuthenticated && (
              <>
                <DropdownMenuSeparator />
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    onNavigate('login');
                    setMobileMenuOpen(false);
                  }}
                  className="justify-start"
                >
                  {t('nav.login', language)}
                </Button>
                <Button
                  size="sm"
                  onClick={() => {
                    onNavigate('register');
                    setMobileMenuOpen(false);
                  }}
                  className="justify-start"
                >
                  {t('nav.register', language)}
                </Button>
              </>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
