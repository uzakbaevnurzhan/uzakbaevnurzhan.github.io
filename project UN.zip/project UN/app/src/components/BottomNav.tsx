import { Home, User, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { Route } from '@/types';
import { t } from '@/i18n';

interface BottomNavProps {
  currentRoute: Route;
  language: string;
  onNavigate: (route: Route) => void;
}

export function BottomNav({ currentRoute, language, onNavigate }: BottomNavProps) {
  const navItems: { route: Route; label: string; icon: React.ReactNode }[] = [
    { route: 'home', label: t('nav.home', language), icon: <Home className="w-5 h-5" /> },
    { route: 'profile', label: t('nav.profile', language), icon: <User className="w-5 h-5" /> },
    { route: 'settings', label: t('nav.settings', language), icon: <Settings className="w-5 h-5" /> },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-background/95 backdrop-blur border-t border-border/40 safe-area-pb">
      <div className="flex items-center justify-around h-16">
        {navItems.map((item) => (
          <Button
            key={item.route}
            variant="ghost"
            size="sm"
            onClick={() => onNavigate(item.route)}
            className={`flex-col h-full flex-1 rounded-none gap-1 ${
              currentRoute === item.route 
                ? 'text-primary bg-primary/5' 
                : 'text-muted-foreground'
            }`}
          >
            {item.icon}
            <span className="text-xs">{item.label}</span>
          </Button>
        ))}
      </div>
    </nav>
  );
}
