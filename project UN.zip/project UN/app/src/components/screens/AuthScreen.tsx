import { useState } from 'react';
import { User, Lock, Mail, Eye, EyeOff, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import type { UserCredentials } from '@/types';
import { t } from '@/i18n';

interface AuthScreenProps {
  mode: 'login' | 'register';
  language: string;
  onLogin: (credentials: UserCredentials) => Promise<{ success: boolean; error?: string }>;
  onRegister: (credentials: UserCredentials) => Promise<{ success: boolean; error?: string }>;
  onSwitchMode: () => void;
  onBack: () => void;
}

export function AuthScreen({
  mode,
  language,
  onLogin,
  onRegister,
  onSwitchMode,
  onBack
}: AuthScreenProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (mode === 'register') {
      if (formData.password !== formData.confirmPassword) {
        setError(t('auth.error.passwordMismatch', language));
        setLoading(false);
        return;
      }
    }

    const credentials: UserCredentials = {
      username: formData.username,
      password: formData.password,
      email: formData.email
    };

    const result = mode === 'login' 
      ? await onLogin(credentials)
      : await onRegister(credentials);

    if (!result.success) {
      setError(result.error || t('common.error', language));
    }

    setLoading(false);
  };

  const isLogin = mode === 'login';

  return (
    <div className="min-h-[80vh] flex flex-col justify-center py-8">
      <div className="flex items-center gap-2 mb-6">
        <Button variant="ghost" size="icon" onClick={onBack}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-xl font-semibold">
          {isLogin ? t('auth.login.title', language) : t('auth.register.title', language)}
        </h1>
      </div>

      <Card className="w-full max-w-md mx-auto">
        <CardHeader className="text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center mx-auto mb-4">
            <User className="w-8 h-8 text-primary-foreground" />
          </div>
          <CardTitle>
            {isLogin ? t('auth.login.title', language) : t('auth.register.title', language)}
          </CardTitle>
          <CardDescription>
            {isLogin 
              ? 'Войдите в свой аккаунт' 
              : 'Создайте новый аккаунт'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {/* Username */}
            <div className="space-y-2">
              <Label htmlFor="username">
                {t('auth.login.username', language)}
              </Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="username"
                  placeholder="username"
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            {/* Email (register only) */}
            {!isLogin && (
              <div className="space-y-2">
                <Label htmlFor="email">
                  {t('auth.register.email', language)}
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="email@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="pl-10"
                  />
                </div>
              </div>
            )}

            {/* Password */}
            <div className="space-y-2">
              <Label htmlFor="password">
                {t('auth.login.password', language)}
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="pl-10 pr-10"
                  required
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-0 top-0 h-full px-3"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </Button>
              </div>
            </div>

            {/* Confirm Password (register only) */}
            {!isLogin && (
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">
                  {t('auth.register.confirmPassword', language)}
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="confirmPassword"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={formData.confirmPassword}
                    onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                    className="pl-10"
                  />
                </div>
              </div>
            )}

            {/* Submit */}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? (
                <span className="animate-pulse">{t('common.loading', language)}</span>
              ) : (
                isLogin ? t('auth.login.submit', language) : t('auth.register.submit', language)
              )}
            </Button>

            {/* Switch Mode */}
            <div className="text-center text-sm">
              <span className="text-muted-foreground">
                {isLogin ? t('auth.login.noAccount', language) : t('auth.register.hasAccount', language)}
              </span>{' '}
              <Button type="button" variant="link" className="p-0" onClick={onSwitchMode}>
                {isLogin ? t('auth.login.register', language) : t('auth.register.login', language)}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
