import { useState } from 'react';
import { 
  Moon, 
  Sun, 
  Monitor, 
  Trash2, 
  RefreshCw,
  ChevronRight,
  AlertTriangle,
  History,
  Shield
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import type { AppSettings } from '@/types';
import { languages, t, formatBytes } from '@/i18n';
import { clearAllData } from '@/utils/db';

interface SettingsScreenProps {
  settings: AppSettings;
  language: string;
  isOnline: boolean;
  cacheSize: { pages: number; assets: number; totalSize: number };
  onUpdateSetting: <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => void;
  onSaveSettings: (settings: Partial<AppSettings>) => void;
  onResetSettings: () => void;
  onCheckUpdate: () => void;
  onClearCache: () => void;
  onNavigate: (route: string) => void;
}

export function SettingsScreen({
  settings,
  language,
  isOnline,
  cacheSize,
  onUpdateSetting,
  onResetSettings,
  onCheckUpdate,
  onClearCache,
  onNavigate
}: SettingsScreenProps) {
  const [showClearCacheDialog, setShowClearCacheDialog] = useState(false);
  const [showResetDialog, setShowResetDialog] = useState(false);
  const [checkingUpdate, setCheckingUpdate] = useState(false);

  const handleCheckUpdate = async () => {
    setCheckingUpdate(true);
    await onCheckUpdate();
    setCheckingUpdate(false);
  };

  const handleClearCache = async () => {
    await clearAllData();
    onClearCache();
    setShowClearCacheDialog(false);
  };

  const handleReset = async () => {
    await onResetSettings();
    setShowResetDialog(false);
  };

  const themeOptions = [
    { value: 'dark', label: t('settings.theme.dark', language), icon: Moon },
    { value: 'light', label: t('settings.theme.light', language), icon: Sun },
    { value: 'auto', label: t('settings.theme.auto', language), icon: Monitor },
  ];

  const fontSizeLabels: Record<number, string> = {
    14: t('settings.fontSize.small', language),
    16: t('settings.fontSize.medium', language),
    18: t('settings.fontSize.large', language),
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Appearance */}
      <Card>
        <CardHeader>
          <CardTitle>{t('settings.appearance', language)}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Theme */}
          <div className="space-y-3">
            <Label>{t('settings.theme', language)}</Label>
            <div className="grid grid-cols-3 gap-2">
              {themeOptions.map((option) => (
                <Button
                  key={option.value}
                  variant={settings.theme === option.value ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => onUpdateSetting('theme', option.value as any)}
                  className="flex-col gap-1 h-auto py-3"
                >
                  <option.icon className="w-4 h-4" />
                  <span className="text-xs">{option.label}</span>
                </Button>
              ))}
            </div>
          </div>

          <Separator />

          {/* Language */}
          <div className="space-y-3">
            <Label>{t('settings.language', language)}</Label>
            <Select 
              value={settings.language} 
              onValueChange={(value) => onUpdateSetting('language', value)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {languages.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code}>
                    <span className="mr-2">{lang.flag}</span>
                    {lang.nativeName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Separator />

          {/* Font Size */}
          <div className="space-y-3">
            <div className="flex justify-between">
              <Label>{t('settings.fontSize', language)}</Label>
              <span className="text-sm text-muted-foreground">
                {fontSizeLabels[settings.fontSize] || settings.fontSize + 'px'}
              </span>
            </div>
            <Slider
              value={[settings.fontSize]}
              onValueChange={([value]) => onUpdateSetting('fontSize', value)}
              min={14}
              max={20}
              step={2}
            />
          </div>
        </CardContent>
      </Card>

      {/* Notifications */}
      <Card>
        <CardHeader>
          <CardTitle>{t('settings.notifications', language)}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>{t('settings.notifications.enable', language)}</Label>
              <p className="text-sm text-muted-foreground">
                {t('settings.notifications.description', language)}
              </p>
            </div>
            <Switch
              checked={settings.notifications}
              onCheckedChange={(checked) => onUpdateSetting('notifications', checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Updates */}
      <Card>
        <CardHeader>
          <CardTitle>{t('settings.updates', language)}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Auto Update */}
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>{t('settings.autoUpdate', language)}</Label>
            </div>
            <Switch
              checked={settings.autoUpdate}
              onCheckedChange={(checked) => onUpdateSetting('autoUpdate', checked)}
            />
          </div>

          <Separator />

          {/* Check Update Button */}
          <Button 
            variant="outline" 
            className="w-full justify-between"
            onClick={handleCheckUpdate}
            disabled={!isOnline || checkingUpdate}
          >
            <span className="flex items-center gap-2">
              <RefreshCw className={`w-4 h-4 ${checkingUpdate ? 'animate-spin' : ''}`} />
              {checkingUpdate ? t('settings.checking', language) : t('settings.checkUpdate', language)}
            </span>
            <ChevronRight className="w-4 h-4" />
          </Button>

          {/* Update History */}
          <Button 
            variant="outline" 
            className="w-full justify-between"
            onClick={() => onNavigate('history')}
          >
            <span className="flex items-center gap-2">
              <History className="w-4 h-4" />
              {t('settings.updateHistory', language)}
            </span>
            <ChevronRight className="w-4 h-4" />
          </Button>
        </CardContent>
      </Card>

      {/* Network */}
      <Card>
        <CardHeader>
          <CardTitle>{t('settings.network', language)}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Data Saver */}
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>{t('settings.dataSaver', language)}</Label>
              <p className="text-sm text-muted-foreground">
                {t('settings.dataSaver.description', language)}
              </p>
            </div>
            <Switch
              checked={settings.dataSaver}
              onCheckedChange={(checked) => onUpdateSetting('dataSaver', checked)}
            />
          </div>

          <Separator />

          {/* Offline Mode */}
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>{t('settings.offlineMode', language)}</Label>
              <p className="text-sm text-muted-foreground">
                {t('settings.offlineMode.description', language)}
              </p>
            </div>
            <Switch
              checked={settings.offlineMode}
              onCheckedChange={(checked) => onUpdateSetting('offlineMode', checked)}
            />
          </div>

          <Separator />

          {/* Cache Info */}
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <Label>{t('settings.cache.size', language)}</Label>
              <Badge variant="secondary">{formatBytes(cacheSize.totalSize)}</Badge>
            </div>
            <div className="text-sm text-muted-foreground">
              {cacheSize.pages} {t('home.pages', language)}, {cacheSize.assets} {t('home.assets', language)}
            </div>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowClearCacheDialog(true)}
              className="w-full"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              {t('settings.cache.clear', language)}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Security */}
      <Card>
        <CardHeader>
          <CardTitle>{t('settings.security', language)}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>{t('settings.security.encryption', language)}</Label>
              <p className="text-sm text-muted-foreground">
                {t('settings.security.encrypted', language)}
              </p>
            </div>
            <Shield className="w-5 h-5 text-green-500" />
          </div>
        </CardContent>
      </Card>

      {/* About */}
      <Card>
        <CardHeader>
          <CardTitle>{t('settings.about', language)}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label>{t('settings.version', language)}</Label>
            <span className="text-sm text-muted-foreground">1.0.0</span>
          </div>
          
          <Separator />
          
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setShowResetDialog(true)}
            className="w-full"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            {t('settings.reset', language)}
          </Button>
        </CardContent>
      </Card>

      {/* Clear Cache Dialog */}
      <Dialog open={showClearCacheDialog} onOpenChange={setShowClearCacheDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('settings.cache.clear', language)}</DialogTitle>
            <DialogDescription>
              Это удалит все кэшированные данные. Приложение потребуется обновить для работы офлайн.
            </DialogDescription>
          </DialogHeader>
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              {formatBytes(cacheSize.totalSize)} данных будут удалены
            </AlertDescription>
          </Alert>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowClearCacheDialog(false)}>
              {t('common.cancel', language)}
            </Button>
            <Button variant="destructive" onClick={handleClearCache}>
              <Trash2 className="w-4 h-4 mr-2" />
              {t('common.delete', language)}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reset Dialog */}
      <Dialog open={showResetDialog} onOpenChange={setShowResetDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('settings.reset', language)}</DialogTitle>
            <DialogDescription>
              Все настройки будут сброшены к значениям по умолчанию.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowResetDialog(false)}>
              {t('common.cancel', language)}
            </Button>
            <Button variant="destructive" onClick={handleReset}>
              <RefreshCw className="w-4 h-4 mr-2" />
              {t('settings.reset', language)}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
