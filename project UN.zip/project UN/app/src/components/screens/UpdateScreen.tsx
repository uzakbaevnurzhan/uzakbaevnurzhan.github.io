import { useState, useEffect } from 'react';
import { 
  Download, 
  CheckCircle, 
  XCircle, 
  RefreshCw, 
  ArrowLeft,
  FileDown,
  Calendar,
  Hash,
  AlertCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import type { UpdateInfo, UpdateProgress } from '@/types';
import { t, formatBytes } from '@/i18n';

interface UpdateScreenProps {
  language: string;
  isOnline: boolean;
  updateInfo: UpdateInfo | null;
  progress: UpdateProgress;
  onCheckUpdate: () => Promise<UpdateInfo | null>;
  onDownload: () => Promise<boolean>;
  onBack: () => void;
}

export function UpdateScreen({
  language,
  isOnline,
  updateInfo,
  progress,
  onCheckUpdate,
  onDownload,
  onBack
}: UpdateScreenProps) {
  const [checking, setChecking] = useState(false);
  const [localUpdateInfo, setLocalUpdateInfo] = useState<UpdateInfo | null>(updateInfo);

  useEffect(() => {
    if (updateInfo) {
      setLocalUpdateInfo(updateInfo);
    }
  }, [updateInfo]);

  const handleCheck = async () => {
    setChecking(true);
    const info = await onCheckUpdate();
    if (info) {
      setLocalUpdateInfo(info);
    }
    setChecking(false);
  };

  const handleDownload = async () => {
    const success = await onDownload();
    if (success) {
      // Reload after successful download
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString(language === 'ru' ? 'ru-RU' : 'en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // No updates state
  if (!localUpdateInfo && !checking && progress.status === 'idle') {
    return (
      <div className="space-y-6 pb-20">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-semibold">{t('update.title', language)}</h1>
        </div>

        <Card>
          <CardContent className="p-8 text-center">
            <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-500" />
            <h2 className="text-xl font-semibold mb-2">{t('update.noUpdates', language)}</h2>
            <p className="text-muted-foreground mb-6">
              {t('update.noUpdates.message', language)}
            </p>
            <Button onClick={handleCheck} disabled={!isOnline || checking}>
              <RefreshCw className={`w-4 h-4 mr-2 ${checking ? 'animate-spin' : ''}`} />
              {t('settings.checkUpdate', language)}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Checking state
  if (checking || progress.status === 'checking') {
    return (
      <div className="space-y-6 pb-20">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-semibold">{t('update.title', language)}</h1>
        </div>

        <Card>
          <CardContent className="p-8 text-center">
            <RefreshCw className="w-16 h-16 mx-auto mb-4 animate-spin text-primary" />
            <h2 className="text-xl font-semibold mb-2">{t('update.checking', language)}</h2>
            <p className="text-muted-foreground">
              {t('update.checking', language)}
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Downloading state
  if (progress.status === 'downloading' || progress.status === 'installing') {
    return (
      <div className="space-y-6 pb-20">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-semibold">{t('update.title', language)}</h1>
        </div>

        <Card>
          <CardContent className="p-8">
            <div className="text-center mb-6">
              <Download className="w-16 h-16 mx-auto mb-4 animate-bounce text-primary" />
              <h2 className="text-xl font-semibold mb-2">
                {progress.status === 'installing' 
                  ? t('update.installing', language) 
                  : t('update.downloading', language)}
              </h2>
              <p className="text-muted-foreground">{progress.message}</p>
            </div>

            <div className="space-y-2">
              <Progress value={progress.progress} className="h-2" />
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>{Math.round(progress.progress)}%</span>
                <span>{progress.message}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Completed state
  if (progress.status === 'completed') {
    return (
      <div className="space-y-6 pb-20">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-semibold">{t('update.title', language)}</h1>
        </div>

        <Card>
          <CardContent className="p-8 text-center">
            <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-500" />
            <h2 className="text-xl font-semibold mb-2">{t('update.completed', language)}</h2>
            <p className="text-muted-foreground mb-6">
              {t('update.completed.message', language)}
            </p>
            <Button onClick={() => window.location.reload()}>
              {t('update.restart', language)}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Error state
  if (progress.status === 'error') {
    return (
      <div className="space-y-6 pb-20">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-semibold">{t('update.title', language)}</h1>
        </div>

        <Card>
          <CardContent className="p-8 text-center">
            <XCircle className="w-16 h-16 mx-auto mb-4 text-destructive" />
            <h2 className="text-xl font-semibold mb-2">{t('update.error', language)}</h2>
            <p className="text-muted-foreground mb-6">{progress.error}</p>
            <Button onClick={handleDownload}>
              <RefreshCw className="w-4 h-4 mr-2" />
              {t('update.retry', language)}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Update available state
  return (
    <div className="space-y-6 pb-20">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" onClick={onBack}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-xl font-semibold">{t('update.title', language)}</h1>
      </div>

      <Alert className="bg-blue-500/10 text-blue-600 border-blue-500/20">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>{t('update.available', language)}</AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>{t('update.available', language)}</CardTitle>
            <Badge variant="default">NEW</Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Version Info */}
          <div className="flex items-center gap-3">
            <Hash className="w-5 h-5 text-muted-foreground" />
            <div>
              <p className="text-sm text-muted-foreground">{t('update.version', language)}</p>
              <p className="font-medium">{localUpdateInfo?.version}</p>
            </div>
          </div>

          {/* Size */}
          <div className="flex items-center gap-3">
            <FileDown className="w-5 h-5 text-muted-foreground" />
            <div>
              <p className="text-sm text-muted-foreground">{t('update.size', language)}</p>
              <p className="font-medium">{formatBytes(localUpdateInfo?.size || 0)}</p>
            </div>
          </div>

          {/* Release Date */}
          <div className="flex items-center gap-3">
            <Calendar className="w-5 h-5 text-muted-foreground" />
            <div>
              <p className="text-sm text-muted-foreground">{t('update.releaseDate', language)}</p>
              <p className="font-medium">{localUpdateInfo && formatDate(localUpdateInfo.releaseDate)}</p>
            </div>
          </div>

          {/* Changelog */}
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">{t('update.changelog', language)}</p>
            <ul className="space-y-1">
              {localUpdateInfo?.changelog.map((item, index) => (
                <li key={index} className="flex items-start gap-2 text-sm">
                  <span className="text-primary mt-1">•</span>
                  {item}
                </li>
              ))}
            </ul>
          </div>

          <Button 
            className="w-full" 
            size="lg"
            onClick={handleDownload}
            disabled={!isOnline}
          >
            <Download className="w-5 h-5 mr-2" />
            {t('update.start', language)}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
