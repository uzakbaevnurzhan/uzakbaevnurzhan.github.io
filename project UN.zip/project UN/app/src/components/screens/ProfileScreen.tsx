import { useState } from 'react';
import { User, Mail, Calendar, Clock, Edit, Lock, Save, X, Camera } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import type { User as UserType } from '@/types';
import { t } from '@/i18n';

interface ProfileScreenProps {
  user: UserType | null;
  isAuthenticated: boolean;
  language: string;
  onUpdateProfile: (updates: Partial<UserType>) => Promise<{ success: boolean; error?: string }>;
  onChangePassword: (oldPassword: string, newPassword: string) => Promise<{ success: boolean; error?: string }>;
  onNavigate: (route: string) => void;
}

export function ProfileScreen({
  user,
  isAuthenticated,
  language,
  onUpdateProfile,
  onChangePassword,
  onNavigate
}: ProfileScreenProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [editedUser, setEditedUser] = useState<Partial<UserType>>({});
  const [passwordData, setPasswordData] = useState({ old: '', new: '', confirm: '' });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  if (!isAuthenticated || !user) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-4">
        <User className="w-16 h-16 text-muted-foreground" />
        <h2 className="text-xl font-semibold">{t('auth.login.title', language)}</h2>
        <p className="text-muted-foreground text-center max-w-sm">
          Войдите в аккаунт, чтобы получить доступ к профилю
        </p>
        <div className="flex gap-2">
          <Button onClick={() => onNavigate('login')}>
            {t('nav.login', language)}
          </Button>
          <Button variant="outline" onClick={() => onNavigate('register')}>
            {t('nav.register', language)}
          </Button>
        </div>
      </div>
    );
  }

  const getInitials = (name: string) => name.slice(0, 2).toUpperCase();

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString(language === 'ru' ? 'ru-RU' : 'en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const handleEdit = () => {
    setEditedUser({ username: user.username, email: user.email });
    setIsEditing(true);
    setError('');
    setSuccess('');
  };

  const handleSave = async () => {
    const result = await onUpdateProfile(editedUser);
    if (result.success) {
      setSuccess('Профиль обновлен');
      setIsEditing(false);
    } else {
      setError(result.error || 'Ошибка обновления');
    }
  };

  const handleChangePassword = async () => {
    if (passwordData.new !== passwordData.confirm) {
      setError(t('auth.error.passwordMismatch', language));
      return;
    }

    const result = await onChangePassword(passwordData.old, passwordData.new);
    if (result.success) {
      setSuccess('Пароль изменен');
      setIsChangingPassword(false);
      setPasswordData({ old: '', new: '', confirm: '' });
    } else {
      setError(result.error || 'Ошибка смены пароля');
    }
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Profile Header */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <div className="relative">
              <Avatar className="w-24 h-24">
                <AvatarFallback className="text-2xl bg-primary/10 text-primary">
                  {getInitials(user.username)}
                </AvatarFallback>
              </Avatar>
              <Button 
                size="icon" 
                variant="secondary" 
                className="absolute bottom-0 right-0 w-8 h-8 rounded-full"
              >
                <Camera className="w-4 h-4" />
              </Button>
            </div>
            <div className="text-center sm:text-left flex-1">
              <h2 className="text-2xl font-bold">{user.username}</h2>
              <p className="text-muted-foreground">{user.email}</p>
              <div className="flex gap-2 mt-2 justify-center sm:justify-start">
                <Badge variant="secondary">{t('nav.profile', language)}</Badge>
                <Badge variant="outline">ID: {user.id.slice(0, 8)}</Badge>
              </div>
            </div>
            <Button variant="outline" onClick={handleEdit}>
              <Edit className="w-4 h-4 mr-2" />
              {t('profile.edit', language)}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Edit Profile Form */}
      {isEditing && (
        <Card>
          <CardHeader>
            <CardTitle>{t('profile.edit', language)}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && <p className="text-sm text-destructive">{error}</p>}
            {success && <p className="text-sm text-green-600">{success}</p>}
            
            <div className="space-y-2">
              <Label>{t('profile.username', language)}</Label>
              <Input
                value={editedUser.username || ''}
                onChange={(e) => setEditedUser({ ...editedUser, username: e.target.value })}
              />
            </div>
            
            <div className="space-y-2">
              <Label>{t('profile.email', language)}</Label>
              <Input
                type="email"
                value={editedUser.email || ''}
                onChange={(e) => setEditedUser({ ...editedUser, email: e.target.value })}
              />
            </div>
            
            <div className="flex gap-2">
              <Button onClick={handleSave}>
                <Save className="w-4 h-4 mr-2" />
                {t('profile.save', language)}
              </Button>
              <Button variant="outline" onClick={() => setIsEditing(false)}>
                <X className="w-4 h-4 mr-2" />
                {t('profile.cancel', language)}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Profile Info */}
      <Card>
        <CardHeader>
          <CardTitle>{t('profile.info', language)}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-3">
            <User className="w-5 h-5 text-muted-foreground" />
            <div>
              <p className="text-sm text-muted-foreground">{t('profile.username', language)}</p>
              <p className="font-medium">{user.username}</p>
            </div>
          </div>
          
          <Separator />
          
          <div className="flex items-center gap-3">
            <Mail className="w-5 h-5 text-muted-foreground" />
            <div>
              <p className="text-sm text-muted-foreground">{t('profile.email', language)}</p>
              <p className="font-medium">{user.email || '-'}</p>
            </div>
          </div>
          
          <Separator />
          
          <div className="flex items-center gap-3">
            <Calendar className="w-5 h-5 text-muted-foreground" />
            <div>
              <p className="text-sm text-muted-foreground">{t('profile.created', language)}</p>
              <p className="font-medium">{formatDate(user.createdAt)}</p>
            </div>
          </div>
          
          <Separator />
          
          <div className="flex items-center gap-3">
            <Clock className="w-5 h-5 text-muted-foreground" />
            <div>
              <p className="text-sm text-muted-foreground">{t('profile.lastLogin', language)}</p>
              <p className="font-medium">{formatDate(user.lastLogin)}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Change Password */}
      <Card>
        <CardHeader>
          <CardTitle>{t('profile.changePassword', language)}</CardTitle>
        </CardHeader>
        <CardContent>
          {!isChangingPassword ? (
            <Button variant="outline" onClick={() => setIsChangingPassword(true)}>
              <Lock className="w-4 h-4 mr-2" />
              {t('profile.changePassword', language)}
            </Button>
          ) : (
            <div className="space-y-4">
              {error && <p className="text-sm text-destructive">{error}</p>}
              
              <div className="space-y-2">
                <Label>{t('auth.login.password', language)}</Label>
                <Input
                  type="password"
                  value={passwordData.old}
                  onChange={(e) => setPasswordData({ ...passwordData, old: e.target.value })}
                />
              </div>
              
              <div className="space-y-2">
                <Label>{t('auth.register.password', language)}</Label>
                <Input
                  type="password"
                  value={passwordData.new}
                  onChange={(e) => setPasswordData({ ...passwordData, new: e.target.value })}
                />
              </div>
              
              <div className="space-y-2">
                <Label>{t('auth.register.confirmPassword', language)}</Label>
                <Input
                  type="password"
                  value={passwordData.confirm}
                  onChange={(e) => setPasswordData({ ...passwordData, confirm: e.target.value })}
                />
              </div>
              
              <div className="flex gap-2">
                <Button onClick={handleChangePassword}>
                  <Save className="w-4 h-4 mr-2" />
                  {t('profile.save', language)}
                </Button>
                <Button variant="outline" onClick={() => setIsChangingPassword(false)}>
                  <X className="w-4 h-4 mr-2" />
                  {t('profile.cancel', language)}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
