import { useEffect, useState } from 'react';
import { 
  Wifi, 
  WifiOff, 
  Download, 
  FileText, 
  Image, 
  CheckCircle,
  AlertCircle,
  Globe,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import type { Route } from '@/types';
import { t, formatBytes } from '@/i18n';
import { isContentCached } from '@/utils/updater';

interface HomeScreenProps {
  language: string;
  isOnline: boolean;
  isCached: boolean;
  stats: {
    pagesCount: number;
    assetsCount: number;
    totalSize: number;
  };
  updateInfo: { version: string; size: number } | null;
  onNavigate: (route: Route) => void;
  onCheckUpdate: () => void;
}

export function HomeScreen({
  language,
  isOnline,
  isCached,
  stats,
  updateInfo,
  onNavigate,
  onCheckUpdate
}: HomeScreenProps) {
  const [localCached, setLocalCached] = useState(isCached);

  useEffect(() => {
    const checkCache = async () => {
      const cached = await isContentCached();
      setLocalCached(cached);
    };
    checkCache();
  }, [isCached]);

  return (
    <div className="space-y-6 pb-20">
      {/* Status Banner */}
      <div className="space-y-4">
        {/* Network Status */}
        <Alert variant={isOnline ? 'default' : 'destructive'}>
          {isOnline ? <Wifi className="h-4 w-4" /> : <WifiOff className="h-4 w-4" />}
          <AlertDescription>
            {isOnline ? t('network.online', language) : t('network.offline', language)}
          </AlertDescription>
        </Alert>

        {/* Offline Ready */}
        {localCached && (
          <Alert className="bg-green-500/10 text-green-600 border-green-500/20">
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>
              {t('home.offline_ready', language)}
            </AlertDescription>
          </Alert>
        )}

        {/* Update Available */}
        {updateInfo && (
          <Alert className="bg-blue-500/10 text-blue-600 border-blue-500/20">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="flex items-center justify-between">
              <span>{t('home.update_available', language)}</span>
              <Button size="sm" onClick={() => onNavigate('update')}>
                {t('update.start', language)}
              </Button>
            </AlertDescription>
          </Alert>
        )}
      </div>

      {/* Welcome Card */}
      <Card>
        <CardHeader>
          <CardTitle>{t('home.welcome', language)}</CardTitle>
          <CardDescription>
            {t('home.description', language)}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center">
              <Globe className="w-8 h-8 text-primary-foreground" />
            </div>
            <div>
              <h3 className="font-semibold">{t('home.title', language)}</h3>
              <p className="text-sm text-muted-foreground">
                {localCached ? 'v1.0.0 • ' + t('home.cached_content', language) : 'v1.0.0'}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                <FileText className="w-5 h-5 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.pagesCount}</p>
                <p className="text-xs text-muted-foreground">{t('home.pages', language)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
                <Image className="w-5 h-5 text-purple-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.assetsCount}</p>
                <p className="text-xs text-muted-foreground">{t('home.assets', language)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-2 md:col-span-1">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
                <Download className="w-5 h-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{formatBytes(stats.totalSize)}</p>
                <p className="text-xs text-muted-foreground">{t('settings.cache.size', language)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Быстрые действия</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <Button 
            variant="outline" 
            className="w-full justify-between"
            onClick={onCheckUpdate}
            disabled={!isOnline}
          >
            <span className="flex items-center gap-2">
              <Download className="w-4 h-4" />
              {t('settings.checkUpdate', language)}
            </span>
            <ArrowRight className="w-4 h-4" />
          </Button>

          <Button 
            variant="outline" 
            className="w-full justify-between"
            onClick={() => onNavigate('settings')}
          >
            <span className="flex items-center gap-2">
              <Globe className="w-4 h-4" />
              {t('nav.settings', language)}
            </span>
            <ArrowRight className="w-4 h-4" />
          </Button>

          <Button 
            variant="outline" 
            className="w-full justify-between"
            onClick={() => onNavigate('history')}
          >
            <span className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              {t('settings.updateHistory', language)}
            </span>
            <ArrowRight className="w-4 h-4" />
          </Button>
        </CardContent>
      </Card>

      {/* Cached Content Preview */}
      {localCached && (
        <Card>
          <CardHeader>
            <CardTitle>{t('home.cached_content', language)}</CardTitle>
            <CardDescription>
              Сайт доступен офлайн
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
              <div className="text-center">
                <Globe className="w-12 h-12 mx-auto mb-2 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">
                  https://sites.google.com/view/uzakbaevnurzhan/
                </p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="mt-4"
                  onClick={() => window.open('https://sites.google.com/view/uzakbaevnurzhan/', '_blank')}
                >
                  Открыть сайт
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
