import { useEffect, useState } from 'react';
import { ArrowLeft, CheckCircle, XCircle, Calendar, FileDown, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { UpdateHistory } from '@/types';
import { t, formatBytes } from '@/i18n';
import { historyDB } from '@/utils/db';

interface HistoryScreenProps {
  language: string;
  onBack: () => void;
}

export function HistoryScreen({ language, onBack }: HistoryScreenProps) {
  const [history, setHistory] = useState<UpdateHistory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    setLoading(true);
    try {
      const data = await historyDB.getRecent(20) as UpdateHistory[];
      setHistory(data);
    } catch (error) {
      console.error('Failed to load history:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString(language === 'ru' ? 'ru-RU' : 'en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" onClick={onBack}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-xl font-semibold">{t('history.title', language)}</h1>
      </div>

      {loading ? (
        <Card>
          <CardContent className="p-8 text-center">
            <RefreshCw className="w-8 h-8 animate-spin mx-auto text-muted-foreground" />
            <p className="mt-4 text-muted-foreground">{t('common.loading', language)}</p>
          </CardContent>
        </Card>
      ) : history.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
              <Calendar className="w-8 h-8 text-muted-foreground" />
            </div>
            <h2 className="text-lg font-semibold mb-2">{t('history.empty', language)}</h2>
            <p className="text-muted-foreground">
              История обновлений будет отображаться здесь
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {history.map((record) => (
            <Card key={record.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">{t('history.version', language)} {record.version}</h3>
                      <Badge 
                        variant={record.status === 'success' ? 'default' : 'destructive'}
                        className="text-xs"
                      >
                        {record.status === 'success' 
                          ? t('history.status.success', language) 
                          : t('history.status.failed', language)}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {formatDate(record.date)}
                      </span>
                      <span className="flex items-center gap-1">
                        <FileDown className="w-4 h-4" />
                        {formatBytes(record.size)}
                      </span>
                    </div>
                  </div>

                  <div className="w-10 h-10 rounded-full flex items-center justify-center bg-muted">
                    {record.status === 'success' ? (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    ) : (
                      <XCircle className="w-5 h-5 text-destructive" />
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
